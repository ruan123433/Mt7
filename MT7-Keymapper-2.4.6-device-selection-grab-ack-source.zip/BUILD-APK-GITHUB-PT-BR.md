# Gerar o APK do MT7 Keymapper 2.4.6 pela nuvem

O projeto inclui GitHub Actions em `.github/workflows/android-build.yml` para preparar JDK, Android SDK, NDK, CMake e Gradle, executar testes e tentar gerar um APK de depuração.

1. Crie um repositório GitHub `MT7-Keymapper` (pode ser privado).
2. Envie o conteúdo extraído deste ZIP para a raiz do repositório, incluindo `.github`.
3. Abra **Actions** e execute/acompanhe **Build MT7 Keymapper APK**.
4. Se a execução concluir com sucesso, baixe o artefato `mt7-keymapper-debug-apk`.
5. Extraia e localize `app-debug.apk`.

Na 2.4.6, o CMake gera os helpers PIE por ABI e os copia para `app/build/generated/mt7-jniLibs/<abi>`. O Gradle inclui essa pasta no empacotamento e usa extração legacy, necessária porque os helpers são executáveis privilegiados iniciados por Root/Shizuku, não bibliotecas carregadas por JNI.

Se o workflow falhar, copie a primeira mensagem de erro completa. Um APK só deve ser considerado gerado quando o workflow confirmar a compilação e publicar o artefato. O código-fonte passou em compilações isoladas Kotlin/C++ no host, mas ainda não houve build Gradle completo nem teste físico no Android 16.
