cmake_minimum_required(VERSION 3.22.1)
project(mt7native LANGUAGES CXX)

add_library(mt7native SHARED native_bridge.cpp)

# Separate privileged executable: it must be launched by an explicitly
# authorized Root/Shizuku process, never called as an ordinary in-app JNI op.
add_executable(mt7-uinput-probe uinput_probe.cpp)
# Package the standalone PIE helper beside the app's native libraries so it can
# be launched by an explicitly authorized su/Shizuku shell. It is NOT JNI.
set_target_properties(mt7-uinput-probe PROPERTIES
    PREFIX ""
    OUTPUT_NAME "libmt7-uinput-probe.so"
    RUNTIME_OUTPUT_DIRECTORY "${CMAKE_LIBRARY_OUTPUT_DIRECTORY}"
)
set(MT7_JNILIBS_OUTPUT_DIR "${CMAKE_CURRENT_SOURCE_DIR}/../../../build/generated/mt7-jniLibs/${ANDROID_ABI}")
add_custom_command(TARGET mt7-uinput-probe POST_BUILD
    COMMAND ${CMAKE_COMMAND} -E make_directory "${MT7_JNILIBS_OUTPUT_DIR}"
    COMMAND ${CMAKE_COMMAND} -E copy "$<TARGET_FILE:mt7-uinput-probe>" "${MT7_JNILIBS_OUTPUT_DIR}/libmt7-uinput-probe.so"
    COMMENT "Packaging privileged MT7 uinput helper for ${ANDROID_ABI}"
)
target_compile_features(mt7-uinput-probe PRIVATE cxx_std_17)
target_compile_options(mt7-uinput-probe PRIVATE -Wall -Wextra -Werror)

find_library(log-lib log)
target_link_libraries(mt7native ${log-lib})
target_compile_features(mt7native PRIVATE cxx_std_17)

# Privileged exclusive USB input capture helper (EVIOCGRAB).
add_executable(mt7-input-grab input_grab.cpp)
set_target_properties(mt7-input-grab PROPERTIES
    PREFIX ""
    OUTPUT_NAME "libmt7-input-grab.so"
    RUNTIME_OUTPUT_DIRECTORY "${CMAKE_LIBRARY_OUTPUT_DIRECTORY}"
)
add_custom_command(TARGET mt7-input-grab POST_BUILD
    COMMAND ${CMAKE_COMMAND} -E make_directory "${MT7_JNILIBS_OUTPUT_DIR}"
    COMMAND ${CMAKE_COMMAND} -E copy "$<TARGET_FILE:mt7-input-grab>" "${MT7_JNILIBS_OUTPUT_DIR}/libmt7-input-grab.so"
    COMMENT "Packaging privileged MT7 input-grab helper for ${ANDROID_ABI}"
)
target_compile_features(mt7-input-grab PRIVATE cxx_std_17)
target_compile_options(mt7-input-grab PRIVATE -Wall -Wextra -Werror)
