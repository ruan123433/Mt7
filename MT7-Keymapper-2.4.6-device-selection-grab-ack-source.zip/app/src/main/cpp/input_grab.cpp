// MT7 privileged input reader with dynamically controlled EVIOCGRAB.
// It observes a USB input node continuously; G grabs it exclusively, R releases it.
#include <cerrno>
#include <cstdio>
#include <cstring>
#include <fcntl.h>
#include <linux/input.h>
#include <poll.h>
#include <string>
#include <sys/ioctl.h>
#include <unistd.h>

int main(int argc, char** argv) {
    if (argc != 3 || std::strcmp(argv[1], "--grab") != 0) {
        std::printf("MT7_GRAB:failed:usage\n");
        return 2;
    }
    const char* path = argv[2];
    if (std::strncmp(path, "/dev/input/event", 16) != 0 || path[16] == '\0') {
        std::printf("MT7_GRAB:failed:invalid-path\n");
        return 2;
    }
    for (const char* p = path + 16; *p; ++p) {
        if (*p < '0' || *p > '9') {
            std::printf("MT7_GRAB:failed:invalid-path\n");
            return 2;
        }
    }
    const int fd = open(path, O_RDONLY | O_NONBLOCK | O_CLOEXEC);
    if (fd < 0) {
        std::printf("MT7_GRAB:failed:open:%d:%s\n", errno, std::strerror(errno));
        return 1;
    }
    bool grabbed = false;
    bool running = true;
    std::puts("MT7_GRAB:ready");
    std::fflush(stdout);
    pollfd descriptors[2]{{fd, POLLIN, 0}, {STDIN_FILENO, POLLIN, 0}};
    while (running) {
        const int result = poll(descriptors, 2, -1);
        if (result < 0) {
            if (errno == EINTR) continue;
            break;
        }
        if (descriptors[1].revents & (POLLIN | POLLHUP)) {
            char command = 0;
            const ssize_t count = read(STDIN_FILENO, &command, 1);
            if (count <= 0 || command == 'Q') {
                running = false;
            } else if (command == 'G' && !grabbed) {
                if (ioctl(fd, EVIOCGRAB, 1) == 0) {
                    grabbed = true;
                    std::puts("MT7_GRAB:active");
                } else {
                    std::printf("MT7_GRAB:failed:grab:%d:%s\n", errno, std::strerror(errno));
                }
                std::fflush(stdout);
            } else if (command == 'R' && grabbed) {
                if (ioctl(fd, EVIOCGRAB, 0) == 0) {
                    grabbed = false;
                    std::puts("MT7_GRAB:released");
                } else {
                    std::printf("MT7_GRAB:failed:release:%d:%s\n", errno, std::strerror(errno));
                    // Exit and close the fd; close is the final kernel-level release path.
                    running = false;
                }
                std::fflush(stdout);
            }
        }
        if (descriptors[0].revents & POLLIN) {
            input_event events[32]{};
            const ssize_t bytes = read(fd, events, sizeof(events));
            if (bytes > 0 && bytes % static_cast<ssize_t>(sizeof(input_event)) == 0) {
                const ssize_t count = bytes / static_cast<ssize_t>(sizeof(input_event));
                for (ssize_t i = 0; i < count; ++i) {
                    const input_event& event = events[i];
                    std::printf("%04x %04x %08x\n", event.type, event.code,
                                static_cast<unsigned int>(event.value));
                }
                std::fflush(stdout);
            } else if (bytes < 0 && errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR) {
                running = false;
            }
        }
        if (descriptors[0].revents & (POLLERR | POLLHUP | POLLNVAL)) running = false;
    }
    if (grabbed && ioctl(fd, EVIOCGRAB, 0) < 0) {
        std::fprintf(stderr, "MT7_GRAB:release-warning:%d:%s\n", errno, std::strerror(errno));
    }
    close(fd); // close also releases an outstanding EVIOCGRAB.
    std::puts("MT7_GRAB:closed");
    return 0;
}
