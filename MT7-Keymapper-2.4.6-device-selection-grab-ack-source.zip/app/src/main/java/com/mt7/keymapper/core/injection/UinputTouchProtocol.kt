package com.mt7.keymapper.core.injection

/**
 * Pure Linux multi-touch protocol builder for a future privileged uinput writer.
 * It only creates event records in memory; it never opens /dev/uinput or injects input.
 * Coordinates are clamped to the virtual device's configured ABS range.
 */
class UinputTouchProtocol(
    private val maxX: Int,
    private val maxY: Int,
    private val maxSlots: Int = DEFAULT_MAX_SLOTS
) {
    data class InputEvent(val type: Int, val code: Int, val value: Int)

    data class PointerState(
        val pointerId: Int,
        val slot: Int,
        val trackingId: Int,
        val x: Int,
        val y: Int
    )

    private val active = LinkedHashMap<Int, PointerState>()
    private var nextTrackingId = 1

    init {
        require(maxX > 0) { "maxX precisa ser maior que zero" }
        require(maxY > 0) { "maxY precisa ser maior que zero" }
        require(maxSlots in 1..MAX_SUPPORTED_SLOTS) { "maxSlots fora do intervalo suportado" }
    }

    @Synchronized
    fun pointerDown(pointerId: Int, x: Int, y: Int): List<InputEvent> {
        require(pointerId >= 0) { "pointerId não pode ser negativo" }
        require(pointerId !in active) { "pointerId já está ativo" }
        require(active.size < maxSlots) { "Limite de contatos simultâneos atingido" }

        val slot = (0 until maxSlots).first { candidate -> active.values.none { it.slot == candidate } }
        val trackingId = allocateTrackingId()
        val state = PointerState(pointerId, slot, trackingId, clampX(x), clampY(y))
        val wasEmpty = active.isEmpty()
        active[pointerId] = state

        return buildList {
            add(abs(ABS_MT_SLOT, slot))
            add(abs(ABS_MT_TRACKING_ID, trackingId))
            add(abs(ABS_MT_POSITION_X, state.x))
            add(abs(ABS_MT_POSITION_Y, state.y))
            if (wasEmpty) {
                add(key(BTN_TOUCH, 1))
                add(key(BTN_TOOL_FINGER, 1))
            }
            add(sync())
        }
    }

    @Synchronized
    fun pointerMove(pointerId: Int, x: Int, y: Int): List<InputEvent> {
        val old = active[pointerId] ?: return emptyList()
        val updated = old.copy(x = clampX(x), y = clampY(y))
        active[pointerId] = updated
        return listOf(
            abs(ABS_MT_SLOT, updated.slot),
            abs(ABS_MT_POSITION_X, updated.x),
            abs(ABS_MT_POSITION_Y, updated.y),
            sync()
        )
    }

    @Synchronized
    fun pointerUp(pointerId: Int): List<InputEvent> {
        val state = active.remove(pointerId) ?: return emptyList()
        val lastPointer = active.isEmpty()
        return buildList {
            add(abs(ABS_MT_SLOT, state.slot))
            add(abs(ABS_MT_TRACKING_ID, -1))
            if (lastPointer) {
                add(key(BTN_TOUCH, 0))
                add(key(BTN_TOOL_FINGER, 0))
            }
            add(sync())
        }
    }

    /** Releases every active contact; safe to call repeatedly. */
    @Synchronized
    fun cancelAll(): List<InputEvent> {
        if (active.isEmpty()) return emptyList()
        val released = active.values.sortedBy { it.slot }
        active.clear()
        return buildList {
            released.forEach { pointer ->
                add(abs(ABS_MT_SLOT, pointer.slot))
                add(abs(ABS_MT_TRACKING_ID, -1))
            }
            add(key(BTN_TOUCH, 0))
            add(key(BTN_TOOL_FINGER, 0))
            add(sync())
        }
    }

    @Synchronized
    fun activePointers(): List<PointerState> = active.values.sortedBy { it.slot }

    private fun allocateTrackingId(): Int {
        val id = nextTrackingId
        nextTrackingId = if (nextTrackingId >= Int.MAX_VALUE - 1) 1 else nextTrackingId + 1
        return id
    }

    private fun clampX(value: Int) = value.coerceIn(0, maxX)
    private fun clampY(value: Int) = value.coerceIn(0, maxY)
    private fun abs(code: Int, value: Int) = InputEvent(EV_ABS, code, value)
    private fun key(code: Int, value: Int) = InputEvent(EV_KEY, code, value)
    private fun sync() = InputEvent(EV_SYN, SYN_REPORT, 0)

    companion object {
        const val EV_SYN = 0x00
        const val EV_KEY = 0x01
        const val EV_ABS = 0x03
        const val SYN_REPORT = 0x00
        const val BTN_TOOL_FINGER = 0x145
        const val BTN_TOUCH = 0x14A
        const val ABS_MT_SLOT = 0x2F
        const val ABS_MT_POSITION_X = 0x35
        const val ABS_MT_POSITION_Y = 0x36
        const val ABS_MT_TRACKING_ID = 0x39
        const val DEFAULT_MAX_SLOTS = 10
        const val MAX_SUPPORTED_SLOTS = 32
    }
}
