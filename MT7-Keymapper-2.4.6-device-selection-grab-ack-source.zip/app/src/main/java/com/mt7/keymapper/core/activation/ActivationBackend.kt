package com.mt7.keymapper.core.activation

enum class BackendKind { ANDROID, SHIZUKU, ROOT }

data class BackendStatus(
    val kind: BackendKind,
    val available: Boolean,
    val detail: String
)

interface ActivationBackend {
    val kind: BackendKind
    suspend fun inspect(): BackendStatus
}
