package com.mt7.keymapper.core.runtime

import android.content.Context
import com.mt7.keymapper.core.activation.BackendKind
import com.mt7.keymapper.core.activation.BackendStatus
import com.mt7.keymapper.core.injection.UinputTouchSession
import com.mt7.keymapper.core.input.OtgEventMapper
import com.mt7.keymapper.core.input.OtgInputEventReader
import com.mt7.keymapper.core.mapping.OtgTouchMappingController
import com.mt7.keymapper.core.mapping.MappingProfile
import com.mt7.keymapper.core.mapping.TouchLayout
import java.io.Closeable
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Owns the complete privileged OTG -> mapping -> uinput pipeline.
 * Caller supplies the selected Linux event node and the actual display pixel size.
 */
class PrivilegedOtgMappingSession private constructor(
    private val reader: OtgInputEventReader,
    private val keyboardReader: OtgInputEventReader?,
    private val touch: UinputTouchSession,
    private val runtime: MappingRuntime,
    private val mapper: OtgEventMapper,
    private val controller: OtgTouchMappingController
) : Closeable {
    private val closed = AtomicBoolean(false)

    fun snapshot(): RuntimeSnapshot = runtime.snapshot()
    fun injectionBackend(): String = touch.backend

    @Synchronized
    fun pause(): RuntimeSnapshot {
        controller.releaseAll()
        return runtime.pause()
    }

    @Synchronized
    fun resume(): RuntimeSnapshot = runtime.resume()

    override fun close() {
        if (!closed.compareAndSet(false, true)) return
        reader.close()
        keyboardReader?.close()
        controller.releaseAll()
        runtime.stop()
        touch.close()
    }

    companion object {
        data class StartResult(val session: PrivilegedOtgMappingSession?, val detail: String)

        fun start(
            context: Context,
            devicePath: String,
            displayWidth: Int,
            displayHeight: Int,
            reader: OtgInputEventReader = OtgInputEventReader(),
            keyboardDevicePath: String? = null,
            keyboardReader: OtgInputEventReader? = keyboardDevicePath?.let { OtgInputEventReader() },
            runtime: MappingRuntime = MappingRuntime(),
            mapper: OtgEventMapper = OtgEventMapper(),
            profile: MappingProfile? = null,
            layoutFactory: (Int, Int) -> TouchLayout = { width, height -> TouchLayout(width, height) },
            onPointerSuspensionChanged: (Boolean) -> Unit = {}
        ): StartResult {
            require(displayWidth > 0 && displayHeight > 0)
            val touchResult = UinputTouchSession.start(
                context = context,
                maxX = displayWidth - 1,
                maxY = displayHeight - 1,
                slots = 10
            )
            val touch = touchResult.session ?: return StartResult(null, touchResult.detail)
            val layout = profile?.let {
                TouchLayout.fromProfile(displayWidth - 1, displayHeight - 1, it)
            } ?: layoutFactory(displayWidth - 1, displayHeight - 1)
            val controller = OtgTouchMappingController(touch, layout) { aiming ->
                // Only the mouse node is grabbed. Keyboard remains available for WASD.
                reader.setExclusiveGrab(aiming)
            }
            val session = PrivilegedOtgMappingSession(reader, keyboardReader, touch, runtime, mapper, controller)
            val kind = if (touch.backend.equals("Root", ignoreCase = true)) BackendKind.ROOT else BackendKind.SHIZUKU
            runtime.selectBackend(BackendStatus(kind, true, touchResult.detail))
            runtime.start()
            val grabHelper = java.io.File(context.applicationInfo.nativeLibraryDir, "libmt7-input-grab.so").absolutePath
            val capture = reader.startNativeCapture(
                devicePath = devicePath,
                helperPath = grabHelper,
                onEvent = { event ->
                    if (!session.closed.get()) runtime.processAndInject(event, mapper, controller)
                },
                onStopped = {
                    if (!session.closed.get()) {
                        controller.releaseAll()
                        runtime.pause()
                    }
                },
                onGrabStatus = { active, error ->
                    onPointerSuspensionChanged(active)
                    if (!active && error != null && !session.closed.get()) {
                        controller.abortViewMode()
                        runtime.pauseAndRelease(controller)
                    }
                }
            )
            if (capture is OtgInputEventReader.StartResult.Failed) {
                session.close()
                return StartResult(null, "uinput criado, mas captura OTG falhou: ${capture.reason}")
            }
            if (keyboardDevicePath != null && keyboardReader != null && keyboardDevicePath != devicePath) {
                val keyboardCapture = keyboardReader.start(
                    devicePath = keyboardDevicePath,
                    onEvent = { event ->
                        if (!session.closed.get()) runtime.processAndInject(event, mapper, controller)
                    },
                    onStopped = { error ->
                        if (error != null && !session.closed.get()) runtime.pauseAndRelease(controller)
                    }
                )
                if (keyboardCapture is OtgInputEventReader.StartResult.Failed) {
                    session.close()
                    return StartResult(null, "Mouse capturado, mas teclado OTG falhou: ${keyboardCapture.reason}")
                }
            }
            val keyboardDetail = if (keyboardDevicePath != null && keyboardDevicePath != devicePath) "; teclado separado em $keyboardDevicePath" else "; teclado precisa estar no mesmo nó ou ser configurado separadamente"
            return StartResult(session, "${touchResult.detail}; mouse EVIOCGRAB em $devicePath$keyboardDetail")
        }
    }
}
