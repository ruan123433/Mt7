package com.mt7.keymapper.core.activation

class ActivationRepository(
    private val shizukuBackend: ShizukuBackend = ShizukuBackend(),
    private val rootBackend: RootBackend = RootBackend()
) {
    suspend fun inspectShizuku(): BackendStatus = shizukuBackend.inspect()

    suspend fun inspectRoot(): BackendStatus = rootBackend.inspect()

    fun inspectAndroid(): BackendStatus = BackendStatus(
        BackendKind.ANDROID,
        available = true,
        detail = "Recursos locais do aplicativo disponíveis."
    )

    // Synchronous status probes used by the Compose screens.
    fun inspectShizukuNow(): BackendStatus = shizukuBackend.inspectNow()

    /** Executes a minimal `id` probe through su to confirm uid=0. */
    fun inspectRootNow(): BackendStatus = rootBackend.inspectNow()

    /** Reports both privileged options without silently selecting either one. */
    fun inspectBothNow(): List<BackendStatus> = listOf(
        inspectRootNow(),
        inspectShizukuNow()
    )

}
