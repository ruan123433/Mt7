package com.mt7.keymapper

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import com.mt7.keymapper.core.mapping.MappingProfile
import com.mt7.keymapper.core.mapping.ControlMarker
import com.mt7.keymapper.core.mapping.ControlPositionMath
import com.mt7.keymapper.core.mapping.ProfileStore
import com.mt7.keymapper.core.mapping.JoystickSettings
import com.mt7.keymapper.core.mapping.JoystickVector
import com.mt7.keymapper.core.mapping.FireMode
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Slider
import com.mt7.keymapper.core.activation.BackendKind
import com.mt7.keymapper.core.activation.BackendStatus
import com.mt7.keymapper.core.mapping.PointerDelta
import com.mt7.keymapper.core.mapping.VisionSettings
import com.mt7.keymapper.core.runtime.LocalTestEventSource
import com.mt7.keymapper.core.runtime.LocalMappingSession
import com.mt7.keymapper.core.runtime.RuntimeState
import com.mt7.keymapper.ui.devices.InputDeviceDiagnosticsPanel
import com.mt7.keymapper.ui.devices.MouseDiagnosticsPanel
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.mt7.keymapper.core.activation.ActivationRepository
import com.mt7.keymapper.core.permissions.PermissionManager
import com.mt7.keymapper.service.MT7InputService
import com.mt7.keymapper.ui.permissions.PermissionScreen
import com.mt7.keymapper.ui.theme.MT7Theme
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {
    private lateinit var permissionManager: PermissionManager
    private val activationRepository = ActivationRepository()

    private val shizukuPermissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == SHIZUKU_REQUEST_CODE) {
            // The Compose screen refreshes when the user returns to the app.
            shizukuGrantResult = grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED
        }
    }

    private var shizukuGrantResult: Boolean? = null

    override fun onStart() {
        super.onStart()
        Shizuku.addRequestPermissionResultListener(shizukuPermissionListener)
    }

    override fun onStop() {
        Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener)
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        if (::permissionManager.isInitialized) {
            // Shizuku status is refreshed by the explicit refresh control.
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        permissionManager = PermissionManager(this)

        setContent {
            MT7Theme {
                var selectedTab by remember { mutableStateOf(0) }
                var shizukuStatus by remember { mutableStateOf(activationRepository.inspectShizukuNow()) }
                var message by remember { mutableStateOf("Escolha um método de ativação.") }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF07111F)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text("MT7 KEYMOUSE", color = Color(0xFF1597FF), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                        Text("Ativação e diagnóstico", color = Color.White, style = MaterialTheme.typography.titleLarge)

                        ScrollableTabRow(selectedTabIndex = selectedTab) {
                            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Shizuku") })
                            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Root") })
                            Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Permissões") })
                            Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 }, text = { Text("Teste local") })
                            Tab(selected = selectedTab == 4, onClick = { selectedTab = 4 }, text = { Text("Dispositivos") })
                            Tab(selected = selectedTab == 5, onClick = { selectedTab = 5 }, text = { Text("Mouse") })
                        }

                        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                        when (selectedTab) {
                            0 -> BackendPanel(
                                title = "Backend Shizuku",
                                status = if (shizukuStatus.available) "AUTORIZADO" else "NÃO AUTORIZADO",
                                detail = shizukuStatus.detail,
                                explanation = "O MT7 usa Shizuku como canal de autorização para operações Android permitidas. O usuário precisa iniciar o Shizuku e conceder acesso ao MT7.",
                                primaryAction = "Solicitar autorização Shizuku",
                                onPrimary = {
                                    val alive = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
                                    if (alive) {
                                        runCatching { Shizuku.requestPermission(SHIZUKU_REQUEST_CODE) }
                                            .onSuccess { message = "Pedido de autorização enviado. Atualize o estado após responder à janela do Shizuku." }
                                            .onFailure { message = "Não foi possível solicitar a autorização: ${it.message}" }
                                    } else {
                                        message = "Shizuku não está iniciado ou o Binder não está disponível."
                                    }
                                },
                                onRefresh = {
                                    shizukuStatus = activationRepository.inspectShizukuNow()
                                    message = shizukuGrantResult?.let {
                                        if (it) "Autorização Shizuku concedida."
                                        else "Autorização Shizuku negada."
                                    } ?: "Estado Shizuku atualizado."
                                }
                            )
                            1 -> BackendPanel(
                                title = "Backend Root",
                                status = if (activationRepository.inspectRootNow().available) "ROOT AUTORIZADO" else "ROOT NÃO AUTORIZADO",
                                detail = activationRepository.inspectRootNow().detail,
                                explanation = "Backend Root independente do Shizuku. A verificação executa apenas id via su; o acesso depende do gerenciador de superusuário do aparelho.",
                                primaryAction = "Verificar Root",
                                onPrimary = { message = activationRepository.inspectRootNow().detail },
                                onRefresh = { message = activationRepository.inspectRootNow().detail }
                            )
                            2 -> PermissionScreen(
                                items = permissionManager.getItems(),
                                onOpen = permissionManager::openAction,
                                modifier = Modifier.fillMaxSize()
                            )
                            3 -> LocalRuntimeTestPanel(modifier = Modifier.fillMaxSize())
                            4 -> InputDeviceDiagnosticsPanel(modifier = Modifier.fillMaxSize())
                            else -> MouseDiagnosticsPanel(modifier = Modifier.fillMaxSize())
                        }
                        }


                        if (selectedTab < 2) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1B2B)),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(message, color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
                                    OutlinedButton(onClick = {
                                        val overlayGranted = permissionManager.getItems().firstOrNull { it.id == "overlay" }?.granted == true
                                        if (overlayGranted) {
                                            ContextCompat.startForegroundService(
                                                this@MainActivity,
                                                Intent(this@MainActivity, MT7InputService::class.java)
                                            )
                                            message = "Serviço MT7 iniciado. A captura global OTG e a ligação ao motor de injeção ainda estão em desenvolvimento."
                                        } else {
                                            message = "Conceda primeiro a permissão de sobreposição na aba Permissões."
                                        }
                                    }, modifier = Modifier.fillMaxWidth()) {
                                        Text("Iniciar mapeamento MT7")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    companion object {
        private const val SHIZUKU_REQUEST_CODE = 701
    }
}

@Composable
private fun BackendPanel(
    title: String,
    status: String,
    detail: String,
    explanation: String,
    primaryAction: String,
    onPrimary: () -> Unit,
    onRefresh: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1B2B)),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(title, color = Color(0xFF1597FF), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(status, color = Color(0xFF35D07F), style = MaterialTheme.typography.labelLarge)
            Text(detail, color = Color.White, style = MaterialTheme.typography.bodyMedium)
            Text(explanation, color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
            Button(onClick = onPrimary, modifier = Modifier.fillMaxWidth()) { Text(primaryAction) }
            OutlinedButton(onClick = onRefresh, modifier = Modifier.fillMaxWidth()) { Text("Atualizar estado") }
        }
    }
}


@Composable
private fun LocalRuntimeTestPanel(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val session = remember { LocalMappingSession() }
    val eventSource = remember { LocalTestEventSource() }
    val profileStore = remember { ProfileStore(context.applicationContext) }

    var profiles by remember { mutableStateOf(profileStore.loadAll()) }
    var activeProfile by remember { mutableStateOf(profiles.first()) }
    var profileName by remember { mutableStateOf(activeProfile.name) }
    var sensitivityX by remember { mutableFloatStateOf(activeProfile.sensitivityX) }
    var sensitivityY by remember { mutableFloatStateOf(activeProfile.sensitivityY) }
    var joystickSensitivityX by remember { mutableFloatStateOf(activeProfile.joystickSensitivityX) }
    var joystickSensitivityY by remember { mutableFloatStateOf(activeProfile.joystickSensitivityY) }
    var joystickDeadzone by remember { mutableFloatStateOf(activeProfile.joystickDeadzone) }
    var joystickPositionX by remember { mutableFloatStateOf(activeProfile.joystickPositionX) }
    var joystickPositionY by remember { mutableFloatStateOf(activeProfile.joystickPositionY) }
    var viewPositionX by remember { mutableFloatStateOf(activeProfile.viewPositionX) }
    var viewPositionY by remember { mutableFloatStateOf(activeProfile.viewPositionY) }
    var firePositionX by remember { mutableFloatStateOf(activeProfile.firePositionX) }
    var firePositionY by remember { mutableFloatStateOf(activeProfile.firePositionY) }
    var draggedControl by remember { mutableStateOf("Nenhum") }
    var joystickInputX by remember { mutableFloatStateOf(0.5f) }
    var joystickInputY by remember { mutableFloatStateOf(-0.5f) }
    var joystickOutput by remember { mutableStateOf<JoystickVector?>(null) }
    var fireMode by remember { mutableStateOf(activeProfile.fireMode) }
    var keyRepeatDelayMs by remember { mutableIntStateOf(activeProfile.keyRepeatDelayMs) }
    var viewToggleBinding by remember { mutableStateOf(activeProfile.viewToggleBinding) }
    var mouseRightMappedKey by remember { mutableStateOf(activeProfile.mouseRightMappedKey) }
    var scrollUpMappedKey by remember { mutableStateOf(activeProfile.scrollUpMappedKey) }
    var scrollDownMappedKey by remember { mutableStateOf(activeProfile.scrollDownMappedKey) }
    var fireSnapshot by remember { mutableStateOf(session.fireSnapshot()) }
    var runtimeState by remember { mutableStateOf(session.snapshot()) }
    var inputX by remember { mutableFloatStateOf(1.0f) }
    var inputY by remember { mutableFloatStateOf(1.0f) }
    var output by remember { mutableStateOf<PointerDelta?>(null) }
    var eventMessage by remember { mutableStateOf("Nenhum evento de teste enviado.") }

    LaunchedEffect(activeProfile.id) {
        context.getSharedPreferences("mt7_mapping_points", android.content.Context.MODE_PRIVATE).edit()
            .putFloat("joystick_x", activeProfile.joystickPositionX)
            .putFloat("joystick_y", activeProfile.joystickPositionY)
            .putFloat("view_x", activeProfile.viewPositionX)
            .putFloat("view_y", activeProfile.viewPositionY)
            .putFloat("fire_x", activeProfile.firePositionX)
            .putFloat("fire_y", activeProfile.firePositionY)
            .apply()
        context.getSharedPreferences("mt7_vision", android.content.Context.MODE_PRIVATE).edit()
            .putFloat("sensitivity_x", activeProfile.sensitivityX)
            .putFloat("sensitivity_y", activeProfile.sensitivityY)
            .apply()
    }

    fun applyProfile(profile: MappingProfile) {
        context.getSharedPreferences("mt7_mapping_points", android.content.Context.MODE_PRIVATE).edit()
            .putFloat("joystick_x", profile.joystickPositionX)
            .putFloat("joystick_y", profile.joystickPositionY)
            .putFloat("view_x", profile.viewPositionX)
            .putFloat("view_y", profile.viewPositionY)
            .putFloat("fire_x", profile.firePositionX)
            .putFloat("fire_y", profile.firePositionY)
            .apply()
        context.getSharedPreferences("mt7_vision", android.content.Context.MODE_PRIVATE).edit()
            .putFloat("sensitivity_x", profile.sensitivityX)
            .putFloat("sensitivity_y", profile.sensitivityY)
            .apply()
        activeProfile = profile
        profileName = profile.name
        sensitivityX = profile.sensitivityX
        sensitivityY = profile.sensitivityY
        joystickSensitivityX = profile.joystickSensitivityX
        joystickSensitivityY = profile.joystickSensitivityY
        joystickDeadzone = profile.joystickDeadzone
        joystickPositionX = profile.joystickPositionX
        joystickPositionY = profile.joystickPositionY
        viewPositionX = profile.viewPositionX
        viewPositionY = profile.viewPositionY
        firePositionX = profile.firePositionX
        firePositionY = profile.firePositionY
        fireMode = profile.fireMode
        keyRepeatDelayMs = profile.keyRepeatDelayMs
        viewToggleBinding = profile.viewToggleBinding
        mouseRightMappedKey = profile.mouseRightMappedKey
        scrollUpMappedKey = profile.scrollUpMappedKey
        scrollDownMappedKey = profile.scrollDownMappedKey
        fireSnapshot = session.setFireMode(profile.fireMode)
        output = null
        joystickOutput = null
        eventMessage = "Perfil '${profile.name}' carregado."
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1B2B)),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            Text("Laboratório de eventos locais", color = Color(0xFF1597FF), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
            Text("Estado: ${runtimeState.state}", color = if (runtimeState.state == RuntimeState.READY) Color(0xFF35D07F) else Color(0xFF9CB0C7))
            Text(runtimeState.message, color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)

            Text("PERFIS", color = Color(0xFF1597FF), fontWeight = FontWeight.Bold)
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                profiles.forEach { profile ->
                    FilterChip(
                        selected = activeProfile.id == profile.id,
                        onClick = { applyProfile(profile) },
                        label = { Text(profile.name) }
                    )
                }
            }
            OutlinedTextField(
                value = profileName,
                onValueChange = { profileName = it.take(28) },
                label = { Text("Nome do perfil") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Text("Sensibilidade X: ${"%.1f".format(sensitivityX)}")
            Slider(value = sensitivityX, onValueChange = { sensitivityX = (it * 10f).toInt() / 10f }, valueRange = 0.1f..10f, steps = 98)
            Text("Sensibilidade Y: ${"%.1f".format(sensitivityY)}")
            Slider(value = sensitivityY, onValueChange = { sensitivityY = (it * 10f).toInt() / 10f }, valueRange = 0.1f..10f, steps = 98)
            Text("Delay entre acionamentos de teclas: ${keyRepeatDelayMs} ms")
            Slider(value = keyRepeatDelayMs.toFloat(), onValueChange = { keyRepeatDelayMs = (it / 10f).toInt() * 10 }, valueRange = 0f..500f, steps = 49)
            Text("0 ms = sem atraso adicional. Ajuste até 500 ms para evitar repetições rápidas.", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)

            Text("CONTROLES DO MOUSE E MODO VISTA", color = Color(0xFF1597FF), fontWeight = FontWeight.Bold)
            OutlinedTextField(
                value = viewToggleBinding,
                onValueChange = { viewToggleBinding = it.take(32) },
                label = { Text("Tecla/botão para alternar modo vista (padrão: Mouse do meio)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Text("Ações aceitas: Nenhuma, ESPAÇO, R ou F. O botão esquerdo permanece reservado ao tiro. O botão direito não controla a vista.", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(value = mouseRightMappedKey, onValueChange = { value -> mouseRightMappedKey = if (value.equals("nenhuma", true)) "Nenhuma" else value.uppercase().take(8) }, label = { Text("Ação do botão direito") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = scrollUpMappedKey, onValueChange = { value -> scrollUpMappedKey = if (value.equals("nenhuma", true)) "Nenhuma" else value.uppercase().take(8) }, label = { Text("Ação do scroll para cima") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = scrollDownMappedKey, onValueChange = { value -> scrollDownMappedKey = if (value.equals("nenhuma", true)) "Nenhuma" else value.uppercase().take(8) }, label = { Text("Ação do scroll para baixo") }, singleLine = true, modifier = Modifier.fillMaxWidth())

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    val updated = MappingProfile(
                        id = activeProfile.id,
                        name = profileName.ifBlank { "Meu perfil" },
                        sensitivityX = sensitivityX,
                        sensitivityY = sensitivityY,
                        joystickSensitivityX = joystickSensitivityX,
                        joystickSensitivityY = joystickSensitivityY,
                        joystickDeadzone = joystickDeadzone,
                        fireMode = fireMode,
                        keyRepeatDelayMs = keyRepeatDelayMs,
                        joystickPositionX = joystickPositionX,
                        joystickPositionY = joystickPositionY,
                        viewPositionX = viewPositionX,
                        viewPositionY = viewPositionY,
                        firePositionX = firePositionX,
                        firePositionY = firePositionY,
                        viewToggleBinding = viewToggleBinding,
                        mouseRightMappedKey = mouseRightMappedKey,
                        scrollUpMappedKey = scrollUpMappedKey,
                        scrollDownMappedKey = scrollDownMappedKey
                    )
                    if (profileStore.save(updated)) {
                        profiles = profileStore.loadAll()
                        applyProfile(updated)
                        eventMessage = "Perfil salvo neste dispositivo."
                    } else {
                        eventMessage = "Não foi possível salvar o perfil."
                    }
                }) { Text("Salvar perfil") }
                OutlinedButton(onClick = {
                    val created = MappingProfile(
                        id = java.util.UUID.randomUUID().toString(),
                        name = profileName.ifBlank { "Novo perfil" },
                        sensitivityX = sensitivityX,
                        sensitivityY = sensitivityY,
                        joystickSensitivityX = joystickSensitivityX,
                        joystickSensitivityY = joystickSensitivityY,
                        joystickDeadzone = joystickDeadzone,
                        fireMode = fireMode,
                        keyRepeatDelayMs = keyRepeatDelayMs,
                        joystickPositionX = joystickPositionX,
                        joystickPositionY = joystickPositionY,
                        viewPositionX = viewPositionX,
                        viewPositionY = viewPositionY,
                        firePositionX = firePositionX,
                        firePositionY = firePositionY,
                        viewToggleBinding = viewToggleBinding,
                        mouseRightMappedKey = mouseRightMappedKey,
                        scrollUpMappedKey = scrollUpMappedKey,
                        scrollDownMappedKey = scrollDownMappedKey
                    )
                    if (profileStore.save(created)) {
                        profiles = profileStore.loadAll()
                        applyProfile(created)
                        eventMessage = "Novo perfil criado."
                    } else eventMessage = "Falha ao criar perfil."
                }) { Text("Novo") }
            }

            Divider(color = Color(0xFF233B55))
            Text("JOYSTICK", color = Color(0xFF1597FF), fontWeight = FontWeight.Bold)
            Text("Sensibilidade horizontal: ${"%.2f".format(joystickSensitivityX)}")
            Slider(value = joystickSensitivityX, onValueChange = { joystickSensitivityX = it; joystickOutput = null }, valueRange = 0.1f..2.0f)
            Text("Sensibilidade vertical: ${"%.2f".format(joystickSensitivityY)}")
            Slider(value = joystickSensitivityY, onValueChange = { joystickSensitivityY = it; joystickOutput = null }, valueRange = 0.1f..2.0f)
            Text("Zona morta: ${"%.2f".format(joystickDeadzone)}")
            Slider(value = joystickDeadzone, onValueChange = { joystickDeadzone = it; joystickOutput = null }, valueRange = 0f..0.5f)
            Text("Entrada do joystick X: ${"%.2f".format(joystickInputX)}")
            Slider(value = joystickInputX, onValueChange = { joystickInputX = it; joystickOutput = null }, valueRange = -1f..1f)
            Text("Entrada do joystick Y: ${"%.2f".format(joystickInputY)}")
            Slider(value = joystickInputY, onValueChange = { joystickInputY = it; joystickOutput = null }, valueRange = -1f..1f)
            Button(
                modifier = Modifier.fillMaxWidth(),
                enabled = runtimeState.state == RuntimeState.READY,
                onClick = {
                    joystickOutput = session.processJoystick(
                        JoystickVector(joystickInputX, joystickInputY),
                        JoystickSettings(joystickSensitivityX, joystickSensitivityY, joystickDeadzone)
                    )
                    eventMessage = if (joystickOutput != null) "Vetor do joystick calculado na sessão local." else "Evento bloqueado pela sessão."
                }
            ) { Text("Testar joystick") }
            Text("Saída joystick X: ${joystickOutput?.x?.let { "%.2f".format(it) } ?: "--"}")
            Text("Saída joystick Y: ${joystickOutput?.y?.let { "%.2f".format(it) } ?: "--"}")

            Divider(color = Color(0xFF233B55))
            Text("POSIÇÕES DOS CONTROLES", color = Color(0xFF1597FF), fontWeight = FontWeight.Bold)
            Text("Prévia proporcional da tela. Ajuste cada marcador pelos controles X/Y.", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
            Canvas(
                modifier = Modifier.fillMaxWidth().height(190.dp).pointerInput(
                    joystickPositionX, joystickPositionY, viewPositionX, viewPositionY,
                    firePositionX, firePositionY
                ) {
                    detectDragGestures(
                        onDragStart = { touch ->
                            val w = size.width.coerceAtLeast(1).toFloat()
                            val h = size.height.coerceAtLeast(1).toFloat()
                            val targets = listOf(
                                ControlMarker("Joystick", joystickPositionX * w, joystickPositionY * h),
                                ControlMarker("Visão", viewPositionX * w, viewPositionY * h),
                                ControlMarker("Atirar", firePositionX * w, firePositionY * h)
                            )
                            draggedControl = ControlPositionMath.nearestMarker(
                                touch.x, touch.y, targets
                            ) ?: "Nenhum"
                        },
                        onDrag = { change, _ ->
                            change.consume()
                            if (draggedControl != "Nenhum") {
                                val nx = ControlPositionMath.normalize(change.position.x, size.width)
                                val ny = ControlPositionMath.normalize(change.position.y, size.height)
                                when (draggedControl) {
                                    "Joystick" -> { joystickPositionX = nx; joystickPositionY = ny }
                                    "Visão" -> { viewPositionX = nx; viewPositionY = ny }
                                    "Atirar" -> { firePositionX = nx; firePositionY = ny }
                                }
                            }
                        },
                        onDragEnd = { draggedControl = "Nenhum" },
                        onDragCancel = { draggedControl = "Nenhum" }
                    )
                }
            ) {
                drawRoundRect(color = Color(0xFF14283D), cornerRadius = androidx.compose.ui.geometry.CornerRadius(16f, 16f))
                drawRoundRect(color = Color(0xFF42617F), style = Stroke(width = 2f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(16f, 16f))
                val radius = 15f
                fun marker(x: Float, y: Float, color: Color, selected: Boolean) {
                    val center = Offset(x * size.width, y * size.height)
                    drawCircle(color = color, radius = radius + if (selected) 4f else 0f, center = center)
                    drawCircle(color = Color.White, radius = radius, center = center, style = Stroke(width = 2f))
                }
                marker(joystickPositionX, joystickPositionY, Color(0xFF1597FF), draggedControl == "Joystick")
                marker(viewPositionX, viewPositionY, Color(0xFFFFC857), draggedControl == "Visão")
                marker(firePositionX, firePositionY, Color(0xFF35D07F), draggedControl == "Atirar")
            }
            Text("Arraste os marcadores para reposicionar. Azul: joystick • Amarelo: visão • Verde: atirar", color = Color.White, style = MaterialTheme.typography.bodySmall)
            Text(if (draggedControl == "Nenhum") "Toque e arraste um marcador." else "Movendo: $draggedControl", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
            Text("Joystick X ${"%.2f".format(joystickPositionX)}  |  Y ${"%.2f".format(joystickPositionY)}")
            Slider(value = joystickPositionX, onValueChange = { joystickPositionX = it }, valueRange = 0f..1f)
            Slider(value = joystickPositionY, onValueChange = { joystickPositionY = it }, valueRange = 0f..1f)
            Text("Visão X ${"%.2f".format(viewPositionX)}  |  Y ${"%.2f".format(viewPositionY)}")
            Slider(value = viewPositionX, onValueChange = { viewPositionX = it }, valueRange = 0f..1f)
            Slider(value = viewPositionY, onValueChange = { viewPositionY = it }, valueRange = 0f..1f)
            Text("Atirar X ${"%.2f".format(firePositionX)}  |  Y ${"%.2f".format(firePositionY)}")
            Slider(value = firePositionX, onValueChange = { firePositionX = it }, valueRange = 0f..1f)
            Slider(value = firePositionY, onValueChange = { firePositionY = it }, valueRange = 0f..1f)

            Divider(color = Color(0xFF233B55))
            Text("BOTÃO DE ATIRAR", color = Color(0xFF1597FF), fontWeight = FontWeight.Bold)
            Text("Entrada do botão: Mouse esquerdo (disparo) • posição ajustável no HUD acima.", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
            Text("Modo", color = Color.White)
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(FireMode.TAP, FireMode.HOLD, FireMode.TOGGLE).forEach { mode ->
                    FilterChip(
                        selected = fireMode == mode,
                        onClick = {
                            fireMode = mode
                            fireSnapshot = session.setFireMode(mode)
                        },
                        label = {
                            Text(when (mode) {
                                FireMode.TAP -> "Toque"
                                FireMode.HOLD -> "Segurar"
                                FireMode.TOGGLE -> "Alternar"
                            })
                        }
                    )
                }
            }
            Text(
                when (fireMode) {
                    FireMode.TAP -> "Um toque gera pressionar e soltar em sequência no simulador."
                    FireMode.HOLD -> "Pressionar mantém o estado ativo até você tocar em Soltar."
                    FireMode.TOGGLE -> "Cada toque alterna entre pressionado e solto."
                },
                color = Color(0xFF9CB0C7),
                style = MaterialTheme.typography.bodySmall
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { fireSnapshot = session.activateFire() }) {
                    Text(when (fireMode) {
                        FireMode.TAP -> "Executar toque"
                        FireMode.HOLD -> "Pressionar"
                        FireMode.TOGGLE -> "Alternar estado"
                    })
                }
                OutlinedButton(
                    onClick = { fireSnapshot = session.releaseFire() },
                    enabled = fireMode == FireMode.HOLD && fireSnapshot.isPressed
                ) { Text("Soltar") }
                OutlinedButton(onClick = { fireSnapshot = session.resetFire() }) { Text("Reset") }
            }
            Text(
                "Estado: ${if (fireSnapshot.isPressed) "PRESSIONADO" else "SOLTO"}  •  Transições: ${fireSnapshot.transitionCount}",
                color = if (fireSnapshot.isPressed) Color(0xFF35D07F) else Color.White
            )

            Divider(color = Color(0xFF233B55))
            Text("VISTA (MOUSE)", color = Color(0xFF1597FF), fontWeight = FontWeight.Bold)
            Text("Entrada X: ${"%.2f".format(inputX)}")
            Slider(value = inputX, onValueChange = { inputX = it }, valueRange = -20f..20f)
            Text("Entrada Y: ${"%.2f".format(inputY)}")
            Slider(value = inputY, onValueChange = { inputY = it }, valueRange = -20f..20f)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    runtimeState = session.start(BackendStatus(BackendKind.ANDROID, true, "Backend local de diagnóstico."))
                    eventMessage = "Runtime local iniciado."
                    output = null
                }) { Text("Iniciar") }
                OutlinedButton(onClick = {
                    runtimeState = session.pause()
                    fireSnapshot = session.fireSnapshot()
                    output = null
                    eventMessage = "Eventos bloqueados enquanto estiver pausado."
                }) { Text("Pausar") }
                OutlinedButton(onClick = {
                    runtimeState = session.stop()
                    fireSnapshot = session.fireSnapshot()
                    output = null
                    eventMessage = "Runtime parado."
                }) { Text("Parar") }
            }
            Button(
                modifier = Modifier.fillMaxWidth(),
                enabled = runtimeState.state == RuntimeState.READY,
                onClick = {
                    val delta = eventSource.createDelta(inputX, inputY)
                    val settings = VisionSettings(
                        sensitivityX = sensitivityX,
                        sensitivityY = sensitivityY
                    )
                    output = session.processPointer(delta, settings)
                    eventMessage = if (output != null) "Evento processado com o perfil '${activeProfile.name}'." else "Evento bloqueado pelo estado do runtime."
                }
            ) { Text("Enviar evento de teste") }
            Text(eventMessage, color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
            Text("Saída X: ${output?.x?.let { "%.2f".format(it) } ?: "--"}")
            Text("Saída Y: ${output?.y?.let { "%.2f".format(it) } ?: "--"}")
            Text("Os perfis salvam joystick, posições e modo do botão. A sessão coordena os testes locais e bloqueia eventos quando pausada ou parada. Não captura entradas do sistema, não injeta comandos em jogos ou outros apps e não altera o comportamento interno do Free Fire.", color = Color(0xFFFFC857), style = MaterialTheme.typography.bodySmall)
        }
    }
}
