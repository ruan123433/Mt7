package com.mt7.keymapper.service

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.SeekBar
import android.widget.ScrollView
import android.provider.Settings

/** Floating MT7 launcher and mapping controls. */
internal class FloatingBallController(
    private val context: Context,
    private val onStop: () -> Unit,
    private val onMappingEnabledChanged: (Boolean) -> Unit
) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var ball: TextView? = null
    private var panel: LinearLayout? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var paused = false
    private var lastTapAt = 0L

    fun show() {
        if (ball != null || !Settings.canDrawOverlays(context)) return
        val view = TextView(context).apply {
            text = "MT7"
            textSize = 14f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = circleBackground()
            contentDescription = "MT7 Keymouse. Dois toques para abrir o menu."
        }
        val params = WindowManager.LayoutParams(
            dp(58), dp(58), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(18)
            y = dp(180)
        }
        view.setOnTouchListener { _, event -> handleBallTouch(event, params) }
        try {
            windowManager.addView(view, params)
            ball = view
        } catch (_: SecurityException) {
            ball = null
        } catch (_: IllegalStateException) {
            ball = null
        }
    }

    fun hide() {
        closePanel()
        ball?.let { runCatching { windowManager.removeView(it) } }
        ball = null
    }

    fun setPaused(value: Boolean) {
        paused = value
        ball?.text = if (paused) "Ⅱ" else "MT7"
        onMappingEnabledChanged(!paused)
    }

    private fun handleBallTouch(event: MotionEvent, params: WindowManager.LayoutParams): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.rawX
                downY = event.rawY
                startX = params.x
                startY = params.y
                moved = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = (event.rawX - downX).toInt()
                val dy = (event.rawY - downY).toInt()
                if (kotlin.math.abs(dx) > dp(5) || kotlin.math.abs(dy) > dp(5)) moved = true
                if (moved) {
                    params.x = startX + dx
                    params.y = startY + dy
                    ball?.let { runCatching { windowManager.updateViewLayout(it, params) } }
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (!moved) {
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastTapAt <= DOUBLE_TAP_MS) togglePanel() else lastTapAt = now
                }
                return true
            }
        }
        return true
    }

    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private var moved = false

    private fun togglePanel() {
        if (activePanelView != null) {
            closePanel()
            return
        }
        val content = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = roundedBackground(Color.rgb(15, 24, 42), dp(18).toFloat())
        }
        content.addView(TextView(context).apply {
            text = "MT7 KEYMOUSE"
            textSize = 16f
            setTextColor(Color.rgb(80, 180, 255))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(8))
        })
        content.addView(menuButton(if (paused) "ATIVAR MAPEAMENTO" else "SUSPENDER MAPEAMENTO") {
            setPaused(!paused)
        })
        content.addView(menuButton("VISÃO / SENSIBILIDADE X-Y") {
            showVisionSettings()
        })
        content.addView(menuButton("CONFIGURAÇÕES") {
            showMessage("Central de configurações MT7")
        })
        content.addView(menuButton("RECOLHER MENU") { closePanel() })
        content.addView(menuButton("PARAR SERVIÇO") { onStop() })

        val p = WindowManager.LayoutParams(
            dp(260), WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            val ballParams = ball?.layoutParams as? WindowManager.LayoutParams
            x = (ballParams?.x ?: dp(18))
            y = (ballParams?.y ?: dp(180)) + dp(66)
        }
        try {
            windowManager.addView(content, p)
            panel = content
            activePanelView = content
            panelParams = p
        } catch (_: Exception) {
            panel = null
            panelParams = null
        }
    }

    /** Local tuning UI for independent pointer sensitivity and polling preference. */
    private fun showVisionSettings() {
        closePanel()
        val prefs = context.getSharedPreferences("mt7_vision", Context.MODE_PRIVATE)
        val rates = listOf(125, 250, 500, 1000)
        var selectedRate = prefs.getInt("polling_hz", 250).let { if (it in rates) it else 250 }
        var suspendPointer = prefs.getBoolean("suspend_pointer_while_aiming", true)
        val content = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = roundedBackground(Color.rgb(15, 24, 42), dp(18).toFloat())
        }
        content.addView(TextView(context).apply {
            text = "VISÃO • SENSIBILIDADE X/Y"
            textSize = 15f
            setTextColor(Color.rgb(80, 180, 255))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        })
        content.addView(TextView(context).apply {
            text = "Eixos independentes • passos de 0,1 • faixa 0,1 a 10,0"
            textSize = 10f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(6), 0, dp(8))
        })
        addSensitivityControl(content, "Sensibilidade X", prefs.getFloat("sensitivity_x", 1f), "sensitivity_x")
        addSensitivityControl(content, "Sensibilidade Y", prefs.getFloat("sensitivity_y", 1f), "sensitivity_y")

        val rateLabel = TextView(context).apply {
            textSize = 12f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(4))
        }
        fun refreshRate() { rateLabel.text = "Taxa selecionada: $selectedRate Hz" }
        refreshRate()
        content.addView(rateLabel)
        val rateRow = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        rates.forEach { hz ->
            rateRow.addView(Button(context).apply {
                text = hz.toString()
                textSize = 10f
                isAllCaps = false
                setOnClickListener {
                    selectedRate = hz
                    prefs.edit().putInt("polling_hz", hz).apply()
                    refreshRate()
                }
            }, LinearLayout.LayoutParams(0, dp(42), 1f))
        }
        content.addView(rateRow)
        val pointerRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(4))
        }
        pointerRow.addView(TextView(context).apply {
            text = "Suspender seta ao mirar"
            textSize = 12f
            setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(0, dp(44), 1f))
        val pointerToggle = android.widget.Switch(context).apply {
            isChecked = suspendPointer
            setOnCheckedChangeListener { _, checked ->
                suspendPointer = checked
                prefs.edit().putBoolean("suspend_pointer_while_aiming", checked).apply()
            }
        }
        pointerRow.addView(pointerToggle)
        content.addView(pointerRow)
        content.addView(TextView(context).apply {
            text = "A opção prepara o modo de suspensão durante o botão direito. Ocultar a seta globalmente em outro app exige suporte do sistema/jogo e ainda não é garantido por esta versão."
            textSize = 10f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(4), 0, dp(8))
        })
        content.addView(TextView(context).apply {
            text = "Hz é uma preferência de processamento. A taxa USB real depende do mouse e do Android; o app não altera o firmware do mouse."
            textSize = 10f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(6), 0, dp(8))
        })
        content.addView(menuButton("VOLTAR AO MENU") { closePanel(); togglePanel() })

        val scroll = ScrollView(context).apply { addView(content) }
        val params = WindowManager.LayoutParams(
            dp(300), dp(460), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            val ballParams = ball?.layoutParams as? WindowManager.LayoutParams
            x = (ballParams?.x ?: dp(18)).coerceAtMost((context.resources.displayMetrics.widthPixels - dp(310)).coerceAtLeast(0))
            y = (ballParams?.y ?: dp(180)) + dp(66)
        }
        try {
            windowManager.addView(scroll, params)
            activePanelView = scroll
            panelParams = params
        } catch (_: Exception) {
            activePanelView = null
            panelParams = null
        }
    }

    private var activePanelView: View? = null

    private fun addSensitivityControl(parent: LinearLayout, label: String, initial: Float, key: String) {
        val prefs = context.getSharedPreferences("mt7_vision", Context.MODE_PRIVATE)
        val valueText = TextView(context).apply {
            text = "$label: ${"%.2f".format(java.util.Locale.US, initial)}"
            textSize = 12f
            setTextColor(Color.WHITE)
        }
        parent.addView(valueText)
        parent.addView(SeekBar(context).apply {
            max = 99
            progress = ((initial.coerceIn(0.1f, 10f) - 0.1f) * 10f).toInt().coerceIn(0, max)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val value = 0.1f + progress / 10f
                    valueText.text = "$label: ${"%.2f".format(java.util.Locale.US, value)}"
                    if (fromUser) prefs.edit().putFloat(key, value).apply()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
        })
    }

    private fun closePanel() {
        activePanelView?.let { runCatching { windowManager.removeView(it) } }
        activePanelView = null
        panel?.let { runCatching { windowManager.removeView(it) } }
        panel = null
        panelParams = null
    }

    private fun menuButton(label: String, action: () -> Unit) = Button(context).apply {
        text = label
        isAllCaps = false
        textSize = 12f
        setTextColor(Color.WHITE)
        setOnClickListener { action() }
    }

    private fun showMessage(message: String) {
        // Keep the overlay compact; detailed controls are implemented in the next editor milestone.
        ball?.contentDescription = message
    }

    private fun circleBackground() = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(Color.rgb(10, 35, 66))
        setStroke(dp(2), Color.rgb(35, 160, 255))
    }

    private fun roundedBackground(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
        setStroke(dp(1), Color.rgb(35, 130, 220))
    }

    private fun overlayType() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    else WindowManager.LayoutParams.TYPE_PHONE

    private fun dp(value: Int): Int = (value * context.resources.displayMetrics.density).toInt()

    companion object { private const val DOUBLE_TAP_MS = 320L }
}
