package com.mt7.keymapper.core.injection

import android.content.Context
import com.mt7.keymapper.core.activation.PrivilegedCommandRunner
import java.io.File

/**
 * Runs the standalone native probe through a privileged shell.
 * Root is always attempted first; Shizuku is attempted only if Root did not
 * complete successfully. The helper creates and destroys a virtual device,
 * but deliberately sends no input_event records.
 */
class UinputProbeRunner(context: Context) {
    private val appContext = context.applicationContext

    data class Execution(
        val backend: String?,
        val result: UinputProbeResult,
        val rootOutput: String? = null
    )

    fun run(): Execution {
        val helper = File(appContext.applicationInfo.nativeLibraryDir, HELPER_NAME)
        if (!helper.isFile) {
            return Execution(
                null,
                UinputProbeResult(
                    false, "helper-missing", null,
                    "Helper nativo não encontrado no pacote do app (${helper.absolutePath}). Recompile e empacote a ABI do aparelho."
                )
            )
        }

        val command = "${shellQuote(helper.absolutePath)} /dev/uinput 1079 2399 10"
        val root = PrivilegedCommandRunner.root(command, timeoutMs = 5_000)
        val rootParsed = UinputProbeResult.parse(root.exitCode, root.output)
        if (root.success && rootParsed.createdAndDestroyed) {
            return Execution("Root", rootParsed)
        }

        val shizuku = PrivilegedCommandRunner.shizuku(command, timeoutMs = 5_000)
        val shizukuParsed = UinputProbeResult.parse(shizuku.exitCode, shizuku.output)
        if (shizuku.success && shizukuParsed.createdAndDestroyed) {
            return Execution("Shizuku", shizukuParsed, root.output)
        }

        val detail = buildString {
            append("Root: ").append(rootParsed.detail)
            append(" | Shizuku: ").append(shizukuParsed.detail)
        }
        return Execution(null, UinputProbeResult(false, "all-backends-failed", null, detail), root.output)
    }

    private fun shellQuote(value: String): String = "'" + value.replace("'", "'\"'\"'") + "'"

    private companion object {
        const val HELPER_NAME = "libmt7-uinput-probe.so"
    }
}
