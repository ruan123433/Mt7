package com.mt7.keymapper.core.input

/**
 * Converts Linux input_event records into semantic, app-local actions.
 * This class deliberately does not synthesize Android input or inject touches.
 */
class OtgEventMapper {
    enum class Kind { KEY, POINTER_MOVE, MOUSE_BUTTON, SCROLL }

    data class Action(
        val kind: Kind,
        val label: String,
        val pressed: Boolean? = null,
        val deltaX: Int = 0,
        val deltaY: Int = 0
    ) {
        fun displayText(): String = when (kind) {
            Kind.KEY, Kind.MOUSE_BUTTON -> "$label ${if (pressed == true) "pressionado" else "solto"}"
            Kind.POINTER_MOVE -> "Mouse Δx=$deltaX Δy=$deltaY"
            Kind.SCROLL -> "Scroll Δx=$deltaX Δy=$deltaY"
        }
    }

    /** Returns null for synchronization and event codes not mapped by MT7 yet. */
    fun map(event: OtgInputEventReader.InputEvent): Action? = when (event.type) {
        EV_KEY -> mapKey(event.code, event.value)
        EV_REL -> when (event.code) {
            REL_X -> Action(Kind.POINTER_MOVE, "Movimento", deltaX = event.value)
            REL_Y -> Action(Kind.POINTER_MOVE, "Movimento", deltaY = event.value)
            REL_WHEEL -> Action(Kind.SCROLL, "Roda vertical", deltaY = event.value)
            REL_HWHEEL -> Action(Kind.SCROLL, "Roda horizontal", deltaX = event.value)
            else -> null
        }
        else -> null
    }

    private fun mapKey(code: Int, value: Int): Action? {
        // Linux input values: 0=release, 1=press, 2=autorepeat.
        if (value !in 0..2) return null
        val pressed = value != 0
        val keyboard = KEY_NAMES[code]
        if (keyboard != null) return Action(Kind.KEY, keyboard, pressed)
        val mouse = MOUSE_BUTTONS[code] ?: return null
        return Action(Kind.MOUSE_BUTTON, mouse, pressed)
    }

    companion object {
        private const val EV_KEY = 0x01
        private const val EV_REL = 0x02
        private const val REL_X = 0x00
        private const val REL_Y = 0x01
        private const val REL_HWHEEL = 0x06
        private const val REL_WHEEL = 0x08

        // Linux input-event-codes.h key codes.
        private val KEY_NAMES = mapOf(
            1 to "ESC", 17 to "W", 30 to "A", 31 to "S", 32 to "D",
            19 to "R", 33 to "F", 57 to "ESPAÇO", 42 to "SHIFT ESQ",
            54 to "SHIFT DIR", 29 to "CTRL ESQ", 97 to "CTRL DIR",
            56 to "ALT ESQ", 100 to "ALT DIR", 14 to "BACKSPACE",
            28 to "ENTER", 15 to "TAB", 16 to "Q", 18 to "E",
            20 to "T", 21 to "Y", 22 to "U", 23 to "I",
            24 to "O", 25 to "P", 44 to "Z", 45 to "X",
            46 to "C", 47 to "V", 48 to "B", 49 to "N", 50 to "M"
        )
        private const val BTN_LEFT = 0x110
        private const val BTN_RIGHT = 0x111
        private const val BTN_MIDDLE = 0x112
        private const val BTN_SIDE = 0x113
        private const val BTN_EXTRA = 0x114
        private val MOUSE_BUTTONS = mapOf(
            BTN_LEFT to "Mouse esquerdo",
            BTN_RIGHT to "Mouse direito",
            BTN_MIDDLE to "Mouse do meio",
            BTN_SIDE to "Mouse lateral 1",
            BTN_EXTRA to "Mouse lateral 2"
        )
    }
}
