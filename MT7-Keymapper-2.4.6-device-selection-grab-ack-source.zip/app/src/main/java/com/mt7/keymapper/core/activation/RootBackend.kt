package com.mt7.keymapper.core.activation

import java.util.concurrent.TimeUnit

/**
 * Root authorization probe. Executes only `id` through the user's su manager;
 * it does not change files, alter game state, or inject input.
 * A visible superuser approval prompt may be shown by the installed su manager.
 */
class RootBackend : ActivationBackend {
    override val kind = BackendKind.ROOT

    override suspend fun inspect(): BackendStatus = inspectNow()

    fun inspectNow(): BackendStatus {
        val process = runCatching {
            ProcessBuilder("su", "-c", "id")
                .redirectErrorStream(true)
                .start()
        }.getOrElse {
            return BackendStatus(
                kind,
                false,
                "Não foi possível iniciar su. Root indisponível ou sem gerenciador instalado."
            )
        }

        return try {
            if (!process.waitFor(3, TimeUnit.SECONDS)) {
                process.destroyForcibly()
                BackendStatus(kind, false, "A verificação Root expirou ou aguarda autorização no gerenciador su.")
            } else {
                val output = process.inputStream.bufferedReader().use { it.readText() }.trim()
                val authorized = process.exitValue() == 0 && output.contains("uid=0")
                BackendStatus(
                    kind,
                    authorized,
                    if (authorized) "Root autorizado e confirmado (uid=0)."
                    else "su foi encontrado, mas Root não foi autorizado. Resultado: ${output.take(180).ifBlank { "sem resposta" }}"
                )
            }
        } catch (error: Exception) {
            process.destroyForcibly()
            BackendStatus(kind, false, "Falha ao verificar autorização Root: ${error.message ?: "erro desconhecido"}")
        }
    }
}
