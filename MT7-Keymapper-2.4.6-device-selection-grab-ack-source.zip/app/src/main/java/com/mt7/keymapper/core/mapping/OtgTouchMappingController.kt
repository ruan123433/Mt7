package com.mt7.keymapper.core.mapping

import com.mt7.keymapper.core.input.OtgEventMapper
import kotlin.math.roundToInt

/** Minimal output contract implemented by the persistent privileged uinput session. */
interface MultiTouchOutput {
    fun pointerDown(pointerId: Int, x: Int, y: Int): Boolean
    fun pointerMove(pointerId: Int, x: Int, y: Int): Boolean
    fun pointerUp(pointerId: Int): Boolean
    fun cancelAll(): Boolean
}

data class TouchLayout(
    val width: Int,
    val height: Int,
    val joystickX: Float = 0.18f,
    val joystickY: Float = 0.78f,
    val joystickRadius: Float = 0.105f,
    val fireX: Float = 0.86f,
    val fireY: Float = 0.72f,
    val lookX: Float = 0.69f,
    val lookY: Float = 0.43f,
    val jumpX: Float = 0.72f,
    val jumpY: Float = 0.78f,
    val reloadX: Float = 0.88f,
    val reloadY: Float = 0.54f,
    val interactX: Float = 0.63f,
    val interactY: Float = 0.72f,
    val lookSensitivityX: Float = 1.6f,
    val lookSensitivityY: Float = 1.6f,
    /** Minimum interval between successive action-key taps; zero disables the limiter. */
    val keyRepeatDelayMs: Int = 0,
    val pollingRateHz: Int = VisionSettings.DEFAULT_POLLING_RATE_HZ,
    val viewToggleBinding: String = "Mouse do meio",
    val mouseRightMappedKey: String = "Nenhuma",
    val scrollUpMappedKey: String = "Nenhuma",
    val scrollDownMappedKey: String = "Nenhuma",
    val suspendPointerWhileAiming: Boolean = true
) {
    init {
        require(width > 0 && height > 0)
        listOf(joystickX, joystickY, fireX, fireY, lookX, lookY, jumpX, jumpY,
            reloadX, reloadY, interactX, interactY).forEach { require(it.isFinite() && it in 0f..1f) }
        require(joystickRadius.isFinite() && joystickRadius in 0.01f..0.3f)
        require(lookSensitivityX.isFinite() && lookSensitivityX in 0.1f..10f && kotlin.math.abs(lookSensitivityX * 10f - (lookSensitivityX * 10f).roundToInt()) < 0.001f)
        require(lookSensitivityY.isFinite() && lookSensitivityY in 0.1f..10f && kotlin.math.abs(lookSensitivityY * 10f - (lookSensitivityY * 10f).roundToInt()) < 0.001f)
        require(keyRepeatDelayMs in 0..500)
        require(pollingRateHz in VisionSettings.SUPPORTED_POLLING_RATES)
        require(viewToggleBinding.isNotBlank() && viewToggleBinding.length <= 32 && viewToggleBinding !in setOf("Mouse esquerdo", "Mouse direito"))
        require(mouseRightMappedKey in setOf("Nenhuma", "ESPAÇO", "R", "F"))
        require(scrollUpMappedKey in setOf("Nenhuma", "ESPAÇO", "R", "F"))
        require(scrollDownMappedKey in setOf("Nenhuma", "ESPAÇO", "R", "F"))
    }

    companion object {
        /** Builds the live OTG HUD layout from the selected saved game profile. */
        fun fromProfile(width: Int, height: Int, profile: MappingProfile): TouchLayout =
            TouchLayout(
                width = width,
                height = height,
                joystickX = profile.joystickPositionX,
                joystickY = profile.joystickPositionY,
                fireX = profile.firePositionX,
                fireY = profile.firePositionY,
                lookX = profile.viewPositionX,
                lookY = profile.viewPositionY,
                lookSensitivityX = profile.sensitivityX,
                lookSensitivityY = profile.sensitivityY,
                keyRepeatDelayMs = profile.keyRepeatDelayMs,
                pollingRateHz = profile.pollingRateHz,
                viewToggleBinding = profile.viewToggleBinding,
                mouseRightMappedKey = profile.mouseRightMappedKey,
                scrollUpMappedKey = profile.scrollUpMappedKey,
                scrollDownMappedKey = profile.scrollDownMappedKey,
                suspendPointerWhileAiming = profile.suspendPointerWhileAiming
            )
    }
}

/**
 * Converts the current MT7 semantic OTG actions into multitouch contacts.
 * Defaults are a starting layout, not a calibrated Free Fire profile.
 */
class OtgTouchMappingController(
    private val output: MultiTouchOutput,
    private val layout: TouchLayout,
    private val onPointerSuspensionChanged: (Boolean) -> Boolean = { true }
) {
    private val heldKeys = mutableSetOf<String>()
    private val heldActionKeys = mutableSetOf<String>()
    private var fireHeld = false
    private var viewModeActive = false
    private var viewToggleHeld = false
    private var lookContactActive = false
    private var lookX = px(layout.lookX)
    private var lookY = pxY(layout.lookY)
    private var lookRemainderX = 0f
    private var lookRemainderY = 0f
    private var joystickActive = false
    private val lastActionAtNanos = mutableMapOf<String, Long>()

    @Synchronized
    fun accept(action: OtgEventMapper.Action): Boolean = when (action.kind) {
        OtgEventMapper.Kind.KEY -> {
            if (action.label == layout.viewToggleBinding) handleViewToggle(action.pressed == true)
            else handleKey(action.label, action.pressed == true)
        }
        OtgEventMapper.Kind.MOUSE_BUTTON -> handleMouse(action.label, action.pressed == true)
        OtgEventMapper.Kind.POINTER_MOVE -> handleMove(action.deltaX, action.deltaY)
        OtgEventMapper.Kind.SCROLL -> handleScroll(action.deltaY)
    }

    private fun handleKey(key: String, pressed: Boolean): Boolean {
        if (key in MOVE_KEYS) {
            if (pressed) heldKeys.add(key) else heldKeys.remove(key)
            return updateJoystick()
        }
        val target = when (key) {
            "ESPAÇO" -> JUMP_ID to (px(layout.jumpX) to pxY(layout.jumpY))
            "R" -> RELOAD_ID to (px(layout.reloadX) to pxY(layout.reloadY))
            "F" -> INTERACT_ID to (px(layout.interactX) to pxY(layout.interactY))
            else -> return true
        }
        if (pressed) {
            if (!heldActionKeys.add(key)) return true
            val now = System.nanoTime()
            val previous = lastActionAtNanos[key] ?: 0L
            if (layout.keyRepeatDelayMs > 0 && previous != 0L &&
                now - previous < layout.keyRepeatDelayMs * 1_000_000L) {
                heldActionKeys.remove(key)
                return true
            }
            lastActionAtNanos[key] = now
            val ok = output.pointerDown(target.first, target.second.first, target.second.second)
            if (!ok) heldActionKeys.remove(key)
            return ok
        }
        if (!heldActionKeys.remove(key)) return true
        return output.pointerUp(target.first)
    }

    private fun handleMouse(button: String, pressed: Boolean): Boolean {
        if (button == "Mouse esquerdo") {
            // Left mouse is reserved exclusively for the in-game fire contact.
            return if (pressed == fireHeld) true else if (pressed) {
                val ok = output.pointerDown(FIRE_ID, px(layout.fireX), pxY(layout.fireY))
                if (ok) fireHeld = true
                ok
            } else {
                val ok = output.pointerUp(FIRE_ID)
                fireHeld = false
                ok
            }
        }
        if (button == layout.viewToggleBinding) return handleViewToggle(pressed)
        if (button == "Mouse direito") return handleKey(layout.mouseRightMappedKey, pressed)
        return true
    }

    private fun handleScroll(deltaY: Int): Boolean {
        if (deltaY == 0) return true
        // Linux REL_WHEEL: positive is wheel-up; negative is wheel-down.
        val key = if (deltaY > 0) layout.scrollUpMappedKey else layout.scrollDownMappedKey
        if (key == "Nenhuma") return true
        // Wheel events are impulses, so emit a short down/up contact pair.
        if (!handleKey(key, true)) return false
        return handleKey(key, false)
    }

    private fun handleViewToggle(pressed: Boolean): Boolean {
        if (pressed == viewToggleHeld) return true
        viewToggleHeld = pressed
        if (!pressed) return true
        return toggleViewMode()
    }

    private fun toggleViewMode(): Boolean {
        if (!viewModeActive) {
            // Do not start the virtual camera contact unless exclusive mouse capture was accepted.
            if (layout.suspendPointerWhileAiming && !onPointerSuspensionChanged(true)) return false
            viewModeActive = true
            lookX = px(layout.lookX).coerceIn(lookMinX(), lookMaxX())
            lookY = pxY(layout.lookY).coerceIn(lookMinY(), lookMaxY())
            lookRemainderX = 0f
            lookRemainderY = 0f
            return true
        }
        val released = if (lookContactActive) output.pointerUp(LOOK_ID) else true
        lookContactActive = false
        viewModeActive = false
        lookRemainderX = 0f
        lookRemainderY = 0f
        val ungrabbed = !layout.suspendPointerWhileAiming || onPointerSuspensionChanged(false)
        return released && ungrabbed
    }

    /** Called after an asynchronous native grab failure or device loss. */
    @Synchronized
    fun abortViewMode() {
        if (lookContactActive) output.pointerUp(LOOK_ID)
        lookContactActive = false
        viewModeActive = false
        viewToggleHeld = false
        lookRemainderX = 0f
        lookRemainderY = 0f
        if (layout.suspendPointerWhileAiming) onPointerSuspensionChanged(false)
        output.cancelAll()
    }

    private fun handleMove(dx: Int, dy: Int): Boolean {
        if (!viewModeActive || (dx == 0 && dy == 0)) return true
        // Keep the virtual finger inside the right-side look zone. When it reaches
        // an edge, lift and re-anchor near the configured center instead of leaving
        // the contact pinned to a screen edge (which would stop further camera motion).
        val minX = lookMinX(); val maxX = lookMaxX()
        val minY = lookMinY(); val maxY = lookMaxY()
        val scaledX = dx * layout.lookSensitivityX + lookRemainderX
        val scaledY = dy * layout.lookSensitivityY + lookRemainderY
        val stepX = scaledX.roundToInt()
        val stepY = scaledY.roundToInt()
        lookRemainderX = scaledX - stepX
        lookRemainderY = scaledY - stepY
        if (stepX == 0 && stepY == 0) return true
        val rawX = lookX + stepX
        val rawY = lookY + stepY
        val crossedEdge = rawX !in minX..maxX || rawY !in minY..maxY
        if (crossedEdge && lookContactActive) {
            val anchorX = px(layout.lookX).coerceIn(minX, maxX)
            val anchorY = pxY(layout.lookY).coerceIn(minY, maxY)
            val overflowX = when { rawX < minX -> rawX - minX; rawX > maxX -> rawX - maxX; else -> 0 }
            val overflowY = when { rawY < minY -> rawY - minY; rawY > maxY -> rawY - maxY; else -> 0 }
            if (!output.pointerUp(LOOK_ID)) { lookContactActive = false; return false }
            lookContactActive = false
            lookX = (anchorX + overflowX).coerceIn(minX, maxX)
            lookY = (anchorY + overflowY).coerceIn(minY, maxY)
            val rebased = output.pointerDown(LOOK_ID, lookX, lookY)
            lookContactActive = rebased
            return rebased
        }
        lookX = rawX.coerceIn(minX, maxX)
        lookY = rawY.coerceIn(minY, maxY)
        val ok = if (lookContactActive) output.pointerMove(LOOK_ID, lookX, lookY)
        else output.pointerDown(LOOK_ID, lookX, lookY)
        if (ok) lookContactActive = true
        return ok
    }

    private fun updateJoystick(): Boolean {
        val horizontal = (if ("D" in heldKeys) 1 else 0) - (if ("A" in heldKeys) 1 else 0)
        val vertical = (if ("S" in heldKeys) 1 else 0) - (if ("W" in heldKeys) 1 else 0)
        if (horizontal == 0 && vertical == 0) {
            if (!joystickActive) return true
            joystickActive = false
            return output.pointerUp(JOYSTICK_ID)
        }
        val radius = (minOf(layout.width, layout.height) * layout.joystickRadius).roundToInt()
        val centerX = px(layout.joystickX)
        val centerY = pxY(layout.joystickY)
        val norm = if (horizontal != 0 && vertical != 0) 0.70710678f else 1f
        val x = (centerX + horizontal * radius * norm).roundToInt().coerceIn(0, layout.width)
        val y = (centerY + vertical * radius * norm).roundToInt().coerceIn(0, layout.height)
        val ok = if (joystickActive) output.pointerMove(JOYSTICK_ID, x, y)
        else output.pointerDown(JOYSTICK_ID, x, y)
        if (ok) joystickActive = true
        return ok
    }

    /** Release every logical contact on pause, stop, device loss, or backend loss. */
    @Synchronized
    fun releaseAll(): Boolean {
        heldKeys.clear(); heldActionKeys.clear(); lastActionAtNanos.clear(); fireHeld = false
        viewModeActive = false; viewToggleHeld = false; lookContactActive = false; joystickActive = false
        lookRemainderX = 0f; lookRemainderY = 0f
        if (layout.suspendPointerWhileAiming) onPointerSuspensionChanged(false)
        return output.cancelAll()
    }

    private fun lookMinX() = (layout.width * 0.52f).roundToInt()
    private fun lookMaxX() = (layout.width * 0.97f).roundToInt()
    private fun lookMinY() = (layout.height * 0.08f).roundToInt()
    private fun lookMaxY() = (layout.height * 0.92f).roundToInt()
    private fun px(fraction: Float) = (fraction * layout.width).roundToInt().coerceIn(0, layout.width)
    private fun pxY(fraction: Float) = (fraction * layout.height).roundToInt().coerceIn(0, layout.height)

    companion object {
        private val MOVE_KEYS = setOf("W", "A", "S", "D")
        private const val JOYSTICK_ID = 0
        private const val LOOK_ID = 1
        private const val FIRE_ID = 2
        private const val JUMP_ID = 3
        private const val RELOAD_ID = 4
        private const val INTERACT_ID = 5
    }
}
