package com.mt7.keymapper.core.mapping

/** Pure geometry helpers for the local control-position editor. */
data class ControlMarker(val id: String, val x: Float, val y: Float)

object ControlPositionMath {
    /** Returns the nearest marker only when the touch starts inside [hitRadiusPx]. */
    fun nearestMarker(
        touchX: Float,
        touchY: Float,
        markers: List<ControlMarker>,
        hitRadiusPx: Float = 52f
    ): String? {
        require(touchX.isFinite() && touchY.isFinite())
        require(hitRadiusPx.isFinite() && hitRadiusPx >= 0f)
        if (markers.isEmpty()) return null
        val nearest = markers.minByOrNull { marker ->
            val dx = touchX - marker.x
            val dy = touchY - marker.y
            dx * dx + dy * dy
        } ?: return null
        val dx = touchX - nearest.x
        val dy = touchY - nearest.y
        return nearest.id.takeIf { dx * dx + dy * dy <= hitRadiusPx * hitRadiusPx }
    }

    /** Converts pixels to a normalized coordinate and safely handles zero-sized bounds. */
    fun normalize(pixel: Float, extent: Int): Float {
        require(pixel.isFinite())
        return (pixel / extent.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f)
    }
}
