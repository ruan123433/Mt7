package com.mt7.keymapper.core.injection

import com.mt7.keymapper.core.activation.PrivilegedCommandRunner
import com.mt7.keymapper.core.activation.RootBackend
import com.mt7.keymapper.core.activation.ShizukuBackend

/**
 * First Android touch-injection transport. Auto mode prefers Root and then Shizuku.
 * It uses Android's `input` shell utility; it does not create a virtual uinput device.
 */
class TouchInjectionRepository(
    private val root: RootBackend = RootBackend(),
    private val shizuku: ShizukuBackend = ShizukuBackend()
) {
    enum class Transport { ROOT_INPUT, SHIZUKU_INPUT }
    data class InjectionResult(val success: Boolean, val transport: Transport?, val detail: String)

    fun detectTransport(): InjectionResult {
        if (root.inspectNow().available) {
            val probe = PrivilegedCommandRunner.root("command -v input")
            if (probe.success && probe.output.contains("input")) {
                return InjectionResult(true, Transport.ROOT_INPUT, "Root disponível; utilitário input encontrado.")
            }
        }
        if (shizuku.inspectNow().available) {
            val probe = PrivilegedCommandRunner.shizuku("command -v input")
            if (probe.success && probe.output.contains("input")) {
                return InjectionResult(true, Transport.SHIZUKU_INPUT, "Shizuku autorizado; utilitário input encontrado.")
            }
        }
        return InjectionResult(false, null, "Nenhum backend privilegiado autorizado com o utilitário input disponível.")
    }

    /** Injects a single screen tap. Coordinates are physical display pixels. */
    fun tap(x: Int, y: Int): InjectionResult = execute("input tap ${x.coerceAtLeast(0)} ${y.coerceAtLeast(0)}")

    /** Injects a swipe/drag. Duration is clamped to avoid malformed shell input. */
    fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, durationMs: Long = 120): InjectionResult {
        val duration = durationMs.coerceIn(1, 10_000)
        val command = "input swipe ${x1.coerceAtLeast(0)} ${y1.coerceAtLeast(0)} ${x2.coerceAtLeast(0)} ${y2.coerceAtLeast(0)} $duration"
        return execute(command)
    }

    private fun execute(command: String): InjectionResult {
        val selected = detectTransport()
        if (!selected.success || selected.transport == null) return selected
        val result = when (selected.transport) {
            Transport.ROOT_INPUT -> PrivilegedCommandRunner.root(command, 3_000)
            Transport.SHIZUKU_INPUT -> PrivilegedCommandRunner.shizuku(command, 3_000)
        }
        return InjectionResult(
            result.success,
            selected.transport,
            if (result.success) "Comando de toque enviado pelo backend ${selected.transport}."
            else "Falha na injeção: ${result.output.ifBlank { "código ${result.exitCode}" }}"
        )
    }
}
