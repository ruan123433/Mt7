package com.mt7.keymapper.nativebridge

object NativeBridge {
    init {
        System.loadLibrary("mt7native")
    }

    external fun nativeVersion(): String

    /**
     * Applies independent linear X/Y sensitivity in native code.
     * This function transforms supplied deltas only; it does not inject input.
     */
    external fun transformDelta(
        dx: Float,
        dy: Float,
        sensitivityX: Float,
        sensitivityY: Float,
        accelerationProtection: Boolean
    ): FloatArray
}
