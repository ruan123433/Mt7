package com.mt7.keymapper.core.input

import com.mt7.keymapper.core.activation.PrivilegedCommandRunner
import com.mt7.keymapper.core.activation.RootBackend
import com.mt7.keymapper.core.activation.ShizukuBackend
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.Closeable
import java.io.InputStreamReader
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/**
 * Reads Linux input events from a selected USB input node using getevent.
 *
 * This is a capture layer only: callers must map events and route them to a
 * separately validated injection backend. It never injects touches itself.
 */
class OtgInputEventReader(
    private val root: RootBackend = RootBackend(),
    private val shizuku: ShizukuBackend = ShizukuBackend()
) : Closeable {

    enum class Backend { ROOT, SHIZUKU }
    data class Device(val path: String, val description: String = "")
    data class InputEvent(
        val devicePath: String,
        val type: Int,
        val code: Int,
        val value: Int,
        val timestamp: String?
    )

    sealed class StartResult {
        data class Started(val backend: Backend, val device: Device) : StartResult()
        data class Failed(val reason: String) : StartResult()
    }

    private var process: Process? = null
    private var readerThread: Thread? = null
    private val running = AtomicBoolean(false)
    @Volatile private var selectedBackend: Backend? = null
    @Volatile private var commandWriter: java.io.BufferedWriter? = null
    @Volatile private var lastCaptureError: String? = null
    private val grabStateLock = Object()
    @Volatile private var grabbed = false
    @Volatile private var grabFailure: String? = null
    @Volatile private var eventExecutor: java.util.concurrent.ExecutorService? = null

    /** Lists event nodes visible to the selected privileged backend. */
    fun listDevices(): List<Device> {
        val backend = chooseBackend() ?: return emptyList()
        val result = runShortCommand(backend, "getevent -pl", 4_000)
        if (!result.success) return emptyList()

        val devices = linkedMapOf<String, String>()
        var currentPath: String? = null
        for (line in result.output.lineSequence()) {
            val path = Regex("""(/dev/input/event\d+)""").find(line)?.groupValues?.get(1)
            if (path != null) {
                currentPath = path
                devices.putIfAbsent(path, "")
            } else if (currentPath != null && line.contains("name:", ignoreCase = true)) {
                val description = line.substringAfter("name:").trim().trim('"')
                devices[currentPath!!] = description
                currentPath = null
            }
        }
        return devices.map { Device(it.key, it.value) }
    }

    /**
     * Starts the bundled native reader. It observes the selected node continuously;
     * EVIOCGRAB is toggled only when the FPS/view mode is active.
     */
    @Synchronized
    fun startNativeCapture(
        devicePath: String,
        helperPath: String,
        onEvent: (InputEvent) -> Unit,
        onStopped: (String?) -> Unit = {},
        onGrabStatus: (Boolean, String?) -> Unit = { _, _ -> }
    ): StartResult {
        stop()
        if (!devicePath.matches(Regex("""/dev/input/event\d+"""))) {
            return StartResult.Failed("Caminho de dispositivo inválido.")
        }
        if (!helperPath.startsWith("/data/" ) || helperPath.contains("\n") || helperPath.contains("\r")) {
            return StartResult.Failed("Caminho do capturador nativo inválido.")
        }
        val backend = chooseNativeBackend(devicePath, helperPath)
            ?: return StartResult.Failed("Root/Shizuku não conseguem executar o capturador ou abrir o dispositivo selecionado.")
        val command = "${shellQuote(helperPath)} --grab ${shellQuote(devicePath)}"
        val started = try {
            startProcess(backend, command)
        } catch (error: Exception) {
            return StartResult.Failed(error.message ?: "Não foi possível iniciar o capturador nativo.")
        }
        val ready = java.util.concurrent.CountDownLatch(1)
        val startupFailure = java.util.concurrent.atomic.AtomicReference<String?>(null)
        process = started
        selectedBackend = backend
        commandWriter = started.outputStream.bufferedWriter()
        lastCaptureError = null
        grabbed = false
        grabFailure = null
        eventExecutor = java.util.concurrent.Executors.newSingleThreadExecutor { task ->
            Thread(task, "MT7-InputDispatch").apply { isDaemon = true }
        }
        running.set(true)
        readerThread = thread(name = "MT7-Grab-${devicePath.substringAfterLast('/')}", isDaemon = true) {
            var failure: String? = null
            try {
                BufferedReader(InputStreamReader(started.inputStream)).use { stream ->
                    while (running.get()) {
                        val line = stream.readLine() ?: break
                        when {
                            line == "MT7_GRAB:ready" -> ready.countDown()
                            line.startsWith("MT7_GRAB:failed:") -> {
                                val detail = line.removePrefix("MT7_GRAB:failed:")
                                if (ready.count > 0) startupFailure.set(detail) else {
                                    lastCaptureError = detail
                                    synchronized(grabStateLock) { grabbed = false; grabFailure = detail; grabStateLock.notifyAll() }
                                    onGrabStatus(false, detail)
                                }
                                ready.countDown()
                            }
                            line == "MT7_GRAB:active" -> {
                                lastCaptureError = null
                                synchronized(grabStateLock) { grabbed = true; grabFailure = null; grabStateLock.notifyAll() }
                                onGrabStatus(true, null)
                            }
                            line == "MT7_GRAB:released" || line == "MT7_GRAB:closed" -> {
                                synchronized(grabStateLock) { grabbed = false; grabStateLock.notifyAll() }
                                onGrabStatus(false, null)
                            }
                            line.startsWith("MT7_GRAB:") -> Unit
                            else -> parseLine(devicePath, line)?.let { event ->
                                eventExecutor?.let { executor ->
                                    runCatching { executor.execute { if (running.get()) onEvent(event) } }
                                }
                            }
                        }
                    }
                }
                if (running.get() && started.exitValueOrNull() != 0) {
                    failure = startupFailure.get() ?: "Capturador exclusivo encerrou; verifique Root/Shizuku, permissões e SELinux."
                }
            } catch (error: Exception) {
                if (running.get()) failure = error.message ?: "Falha lendo eventos capturados."
            } finally {
                ready.countDown()
                running.set(false)
                commandWriter = null
                synchronized(grabStateLock) { grabbed = false; grabStateLock.notifyAll() }
                eventExecutor?.shutdownNow()
                eventExecutor = null
                runCatching { started.destroy() }
                onStopped(failure)
            }
        }
        if (!ready.await(3, java.util.concurrent.TimeUnit.SECONDS)) {
            stop()
            return StartResult.Failed("O capturador nativo não confirmou inicialização em até 3 segundos.")
        }
        val failed = startupFailure.get()
        if (failed != null) {
            stop()
            return StartResult.Failed("EVIOCGRAB não foi ativado: $failed")
        }
        return StartResult.Started(backend, Device(devicePath))
    }

    /** Toggle EVIOCGRAB and wait for the helper's kernel ioctl acknowledgement. */
    @Synchronized
    fun setExclusiveGrab(enabled: Boolean): Boolean {
        val writer = commandWriter ?: return false
        synchronized(grabStateLock) {
            if (!enabled && !grabbed) return true
            if (enabled && grabbed) return true
            grabFailure = null
            return try {
                writer.write(if (enabled) "G" else "R")
                writer.flush()
                val deadline = System.nanoTime() + java.util.concurrent.TimeUnit.MILLISECONDS.toNanos(900)
                while (grabbed != enabled && grabFailure == null && running.get()) {
                    val remaining = deadline - System.nanoTime()
                    if (remaining <= 0L) break
                    java.util.concurrent.TimeUnit.NANOSECONDS.timedWait(grabStateLock, remaining)
                }
                if (grabbed == enabled) true else {
                    lastCaptureError = grabFailure ?: "Sem confirmação do EVIOCGRAB dentro do prazo."
                    false
                }
            } catch (error: Exception) {
                lastCaptureError = error.message ?: "Falha enviando comando EVIOCGRAB."
                false
            }
        }
    }

    fun captureError(): String? = lastCaptureError

    private fun shellQuote(value: String): String = "'" + value.replace("'", "'\\''") + "'"

    /**
     * Starts a streaming getevent process for one enumerated event node.
     * Device paths are strictly validated to prevent shell argument injection.
     */
    @Synchronized
    fun start(
        devicePath: String,
        onEvent: (InputEvent) -> Unit,
        onStopped: (String?) -> Unit = {}
    ): StartResult {
        stop()
        if (!devicePath.matches(Regex("""/dev/input/event\d+"""))) {
            return StartResult.Failed("Caminho de dispositivo inválido.")
        }
        val backend = chooseBackend()
            ?: return StartResult.Failed("Root e Shizuku não estão autorizados.")
        val command = "getevent -t $devicePath"
        val started = try {
            startProcess(backend, command)
        } catch (error: Exception) {
            return StartResult.Failed(error.message ?: "Não foi possível iniciar getevent.")
        }

        process = started
        selectedBackend = backend
        running.set(true)
        readerThread = thread(name = "MT7-OTG-${devicePath.substringAfterLast('/')}", isDaemon = true) {
            var failure: String? = null
            try {
                BufferedReader(InputStreamReader(started.inputStream)).use { reader ->
                    while (running.get()) {
                        val line = reader.readLine() ?: break
                        parseLine(devicePath, line)?.let(onEvent)
                    }
                }
                if (running.get() && started.exitValueOrNull() != 0) {
                    failure = "getevent encerrou; verifique permissões do dispositivo e SELinux."
                }
            } catch (error: Exception) {
                if (running.get()) failure = error.message ?: "Falha lendo eventos OTG."
            } finally {
                running.set(false)
                runCatching { started.destroy() }
                onStopped(failure)
            }
        }
        return StartResult.Started(backend, Device(devicePath))
    }

    @Synchronized
    override fun close() = stop()

    @Synchronized
    fun stop() {
        running.set(false)
        synchronized(grabStateLock) { grabbed = false; grabStateLock.notifyAll() }
        eventExecutor?.shutdownNow()
        eventExecutor = null
        commandWriter?.let { writer ->
            runCatching { writer.write("Q"); writer.flush(); writer.close() }
        }
        commandWriter = null
        process?.let {
            runCatching { if (!it.waitFor(300, java.util.concurrent.TimeUnit.MILLISECONDS)) it.destroy() }
            if (it.isAlive) runCatching { it.destroyForcibly() }
        }
        process = null
        readerThread?.interrupt()
        readerThread = null
        selectedBackend = null
    }

    fun activeBackend(): Backend? = selectedBackend


    /** Root first, then Shizuku; native capture does not require the getevent binary. */
    private fun chooseNativeBackend(devicePath: String, helperPath: String): Backend? {
        val probeCommand = "test -r ${shellQuote(devicePath)} && test -x ${shellQuote(helperPath)}"
        if (root.inspectNow().available) {
            val probe = PrivilegedCommandRunner.root(probeCommand, 2_000)
            if (probe.success) return Backend.ROOT
        }
        if (shizuku.inspectNow().available) {
            val probe = PrivilegedCommandRunner.shizuku(probeCommand, 2_000)
            if (probe.success) return Backend.SHIZUKU
        }
        return null
    }

    private fun chooseBackend(): Backend? {
        if (root.inspectNow().available) {
            val probe = PrivilegedCommandRunner.root("command -v getevent")
            if (probe.success && probe.output.contains("getevent")) return Backend.ROOT
        }
        if (shizuku.inspectNow().available) {
            val probe = PrivilegedCommandRunner.shizuku("command -v getevent")
            if (probe.success && probe.output.contains("getevent")) return Backend.SHIZUKU
        }
        return null
    }

    private fun runShortCommand(backend: Backend, command: String, timeoutMs: Long): PrivilegedCommandRunner.Result =
        when (backend) {
            Backend.ROOT -> PrivilegedCommandRunner.root(command, timeoutMs)
            Backend.SHIZUKU -> PrivilegedCommandRunner.shizuku(command, timeoutMs)
        }

    @Suppress("DEPRECATION")
    private fun startProcess(backend: Backend, command: String): Process = when (backend) {
        Backend.ROOT -> ProcessBuilder("su", "-c", command).redirectErrorStream(true).start()
        Backend.SHIZUKU -> {
            check(Shizuku.pingBinder()) { "Shizuku desconectado." }
            check(Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                "Permissão Shizuku não concedida."
            }
            Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
        }
    }

    companion object {
        private val EVENT_PATTERN = Regex(
            """(?:\[\s*([0-9.]+)\s*\]\s*)?(?:/dev/input/event\d+:\s*)?([0-9a-fA-F]{4})\s+([0-9a-fA-F]{4})\s+([0-9a-fA-F]{8})"""
        )

        /** Parses getevent -t hexadecimal output. EV_KEY=1, EV_REL=2, EV_ABS=3. */
        fun parseLine(devicePath: String, line: String): InputEvent? {
            val match = EVENT_PATTERN.find(line) ?: return null
            return runCatching {
                InputEvent(
                    devicePath = devicePath,
                    timestamp = match.groupValues[1].ifBlank { null },
                    type = match.groupValues[2].toInt(16),
                    code = match.groupValues[3].toInt(16),
                    value = match.groupValues[4].toLong(16).toInt()
                )
            }.getOrNull()
        }

        private fun Process.exitValueOrNull(): Int? = runCatching { exitValue() }.getOrNull()
    }
}
