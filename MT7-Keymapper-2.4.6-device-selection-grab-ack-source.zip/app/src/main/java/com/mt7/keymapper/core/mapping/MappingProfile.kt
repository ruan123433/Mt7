package com.mt7.keymapper.core.mapping

import kotlin.math.roundToInt

data class MappingProfile(
    val id: String,
    val name: String,
    val sensitivityX: Float = 1.0f,
    val sensitivityY: Float = 1.0f,
    val acceleration: Float = 0.0f,
    val smoothing: Float = 0.0f,
    val joystickSensitivityX: Float = 1.0f,
    val joystickSensitivityY: Float = 1.0f,
    val joystickDeadzone: Float = 0.08f,
    val fireMode: FireMode = FireMode.TAP,
    /** Minimum interval between repeated mapped action-key activations (0 = no added delay). */
    val keyRepeatDelayMs: Int = 0,
    val joystickPositionX: Float = 0.18f,
    val joystickPositionY: Float = 0.78f,
    val viewPositionX: Float = 0.72f,
    val viewPositionY: Float = 0.48f,
    val firePositionX: Float = 0.86f,
    val firePositionY: Float = 0.72f,
    /** Requested event processing/polling preference; cannot change the USB mouse firmware rate. */
    val pollingRateHz: Int = VisionSettings.DEFAULT_POLLING_RATE_HZ,
    /** Binding that toggles relative-look mode; independent from the right mouse button. */
    val viewToggleBinding: String = "Mouse do meio",
    /** Optional normal mapped action for right mouse; accepted values: Nenhuma, ESPAÇO, R, F. */
    val mouseRightMappedKey: String = "Nenhuma",
    /** Optional tap action for vertical wheel up; accepted values: Nenhuma, ESPAÇO, R, F. */
    val scrollUpMappedKey: String = "Nenhuma",
    /** Optional tap action for vertical wheel down; accepted values: Nenhuma, ESPAÇO, R, F. */
    val scrollDownMappedKey: String = "Nenhuma",
    /** Ask the platform adapter to suppress pointer while relative-look mode is active. */
    val suspendPointerWhileAiming: Boolean = true
) {
    init {
        require(sensitivityX in 0.1f..10.0f && kotlin.math.abs(sensitivityX * 10f - (sensitivityX * 10f).roundToInt()) < 0.001f)
        require(sensitivityY in 0.1f..10.0f && kotlin.math.abs(sensitivityY * 10f - (sensitivityY * 10f).roundToInt()) < 0.001f)
        require(acceleration in 0.0f..3.0f)
        require(smoothing in 0.0f..1.0f)
        require(keyRepeatDelayMs in 0..500)
        require(joystickSensitivityX in 0.1f..2.0f)
        require(joystickSensitivityY in 0.1f..2.0f)
        require(joystickDeadzone in 0.0f..0.5f)
        require(joystickPositionX in 0.0f..1.0f && joystickPositionY in 0.0f..1.0f)
        require(viewPositionX in 0.0f..1.0f && viewPositionY in 0.0f..1.0f)
        require(firePositionX in 0.0f..1.0f && firePositionY in 0.0f..1.0f)
        require(pollingRateHz in VisionSettings.SUPPORTED_POLLING_RATES)
        require(viewToggleBinding.isNotBlank() && viewToggleBinding.length <= 32 && viewToggleBinding !in setOf("Mouse esquerdo", "Mouse direito"))
        require(mouseRightMappedKey in setOf("Nenhuma", "ESPAÇO", "R", "F"))
        require(scrollUpMappedKey in setOf("Nenhuma", "ESPAÇO", "R", "F"))
        require(scrollDownMappedKey in setOf("Nenhuma", "ESPAÇO", "R", "F"))
    }
}
