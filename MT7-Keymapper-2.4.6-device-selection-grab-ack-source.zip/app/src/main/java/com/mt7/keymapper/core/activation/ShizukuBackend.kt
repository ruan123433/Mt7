package com.mt7.keymapper.core.activation

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/**
 * Shizuku authorization/status adapter.
 * It only checks connection and the app's explicit Shizuku grant.
 * It does not execute shell commands or inject input.
 */
class ShizukuBackend : ActivationBackend {
    override val kind = BackendKind.SHIZUKU

    override suspend fun inspect(): BackendStatus = inspectNow()

    fun inspectNow(): BackendStatus {
        val binderAlive = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        if (!binderAlive) {
            return BackendStatus(
                kind,
                false,
                "Shizuku desconectado. Inicie o Shizuku e atualize o estado."
            )
        }

        val granted = runCatching {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        }.getOrDefault(false)

        val uid = runCatching { Shizuku.getUid() }.getOrNull()
        val identity = when (uid) {
            0 -> "Identidade informada pelo Shizuku: Root."
            2000 -> "Identidade informada pelo Shizuku: ADB/Shell."
            null -> "Identidade não identificada."
            else -> "UID informado pelo Shizuku: $uid."
        }

        return BackendStatus(
            kind,
            granted,
            if (granted) "$identity MT7 autorizado pelo Shizuku."
            else "$identity Falta conceder a autorização do MT7."
        )
    }
}
