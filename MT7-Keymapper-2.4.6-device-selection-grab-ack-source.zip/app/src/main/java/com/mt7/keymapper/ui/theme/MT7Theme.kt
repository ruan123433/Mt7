package com.mt7.keymapper.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val MT7Colors = darkColorScheme(
    primary = Color(0xFF1597FF),
    background = Color(0xFF07111F),
    surface = Color(0xFF0D1B2B),
    onPrimary = Color.White,
    onBackground = Color.White,
    onSurface = Color.White
)

@Composable
fun MT7Theme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = MT7Colors, content = content)
}
