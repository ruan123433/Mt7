package com.mt7.keymapper.core.mapping

import kotlin.math.sqrt

data class JoystickSettings(
    val sensitivityX: Float = 1.0f,
    val sensitivityY: Float = 1.0f,
    val deadzone: Float = 0.08f
) {
    init {
        require(sensitivityX.isFinite() && sensitivityX in 0.1f..2.0f)
        require(sensitivityY.isFinite() && sensitivityY in 0.1f..2.0f)
        require(deadzone.isFinite() && deadzone in 0.0f..0.5f)
    }
}

data class JoystickVector(val x: Float, val y: Float)

/**
 * Normalized joystick transform for the in-app simulator only.
 * Applies a radial deadzone, axis sensitivity, then clamps to [-1, 1].
 */
class JoystickTransform {
    fun apply(input: JoystickVector, settings: JoystickSettings): JoystickVector {
        require(input.x.isFinite() && input.y.isFinite())
        val x = input.x.coerceIn(-1f, 1f)
        val y = input.y.coerceIn(-1f, 1f)
        val magnitude = sqrt(x * x + y * y)
        if (magnitude <= settings.deadzone) return JoystickVector(0f, 0f)

        val scaledMagnitude = ((magnitude - settings.deadzone) / (1f - settings.deadzone))
            .coerceIn(0f, 1f)
        val normalizedFactor = if (magnitude > 0f) scaledMagnitude / magnitude else 0f
        return JoystickVector(
            x = (x * normalizedFactor * settings.sensitivityX).coerceIn(-1f, 1f),
            y = (y * normalizedFactor * settings.sensitivityY).coerceIn(-1f, 1f)
        )
    }
}
