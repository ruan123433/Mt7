package com.mt7.keymapper.core.runtime

import com.mt7.keymapper.core.activation.BackendKind
import com.mt7.keymapper.core.activation.BackendStatus
import com.mt7.keymapper.core.input.OtgEventMapper
import com.mt7.keymapper.core.input.OtgInputEventReader
import com.mt7.keymapper.core.mapping.MultiTouchOutput
import com.mt7.keymapper.core.mapping.OtgTouchMappingController
import com.mt7.keymapper.core.mapping.TouchLayout
import org.junit.Assert.*
import org.junit.Test

class MappingRuntimeInjectionTest {
    private class FakeOutput : MultiTouchOutput {
        val calls = mutableListOf<String>()
        override fun pointerDown(pointerId: Int, x: Int, y: Int) = true.also { calls += "D:$pointerId" }
        override fun pointerMove(pointerId: Int, x: Int, y: Int) = true.also { calls += "M:$pointerId" }
        override fun pointerUp(pointerId: Int) = true.also { calls += "U:$pointerId" }
        override fun cancelAll() = true.also { calls += "C" }
    }

    @Test fun readyRuntimeRoutesCapturedMouseButtonToTouchOutput() {
        val output = FakeOutput()
        val controller = OtgTouchMappingController(output, TouchLayout(1080, 2400))
        val runtime = MappingRuntime()
        runtime.selectBackend(BackendStatus(BackendKind.ROOT, true, "uinput criado"))
        runtime.start()
        val event = OtgInputEventReader.InputEvent("/dev/input/event4", 1, 0x110, 1, null)
        assertTrue(runtime.processAndInject(event, OtgEventMapper(), controller))
        assertEquals("D:2", output.calls.single())
    }

    @Test fun stoppedRuntimeDoesNotInject() {
        val output = FakeOutput()
        val controller = OtgTouchMappingController(output, TouchLayout(1080, 2400))
        val runtime = MappingRuntime()
        runtime.selectBackend(BackendStatus(BackendKind.ROOT, true, "ok"))
        val event = OtgInputEventReader.InputEvent("/dev/input/event4", 1, 0x110, 1, null)
        assertFalse(runtime.processAndInject(event, OtgEventMapper(), controller))
        assertTrue(output.calls.isEmpty())
    }
}
