package com.mt7.keymapper.core.input

import org.junit.Assert.*
import org.junit.Test

class OtgInputEventReaderTest {
    @Test fun parsesKeyEvent() {
        val event = OtgInputEventReader.parseLine(
            "/dev/input/event4", "[ 123.456] /dev/input/event4: 0001 0110 00000001"
        )
        assertNotNull(event)
        assertEquals(1, event!!.type)
        assertEquals(0x0110, event.code)
        assertEquals(1, event.value)
        assertEquals("123.456", event.timestamp)
    }

    @Test fun parsesGeteventTimestampWithPaddedWhitespace() {
        val event = OtgInputEventReader.parseLine(
            "/dev/input/event6", "[  1234.123456] /dev/input/event6: 0001 001e 00000001"
        )
        assertNotNull(event)
        assertEquals("1234.123456", event!!.timestamp)
        assertEquals(1, event.value)
    }

    @Test fun parsesRelativeMouseEvent() {
        val event = OtgInputEventReader.parseLine(
            "/dev/input/event5", "[ 7.25] 0002 0000 fffffffe"
        )
        assertNotNull(event)
        assertEquals(2, event!!.type)
        assertEquals(0, event.code)
        assertEquals(-2, event.value)
    }

    @Test fun parsesNativeGrabHelperEventLineWithoutTimestampOrDevicePrefix() {
        val event = OtgInputEventReader.parseLine(
            "/dev/input/event7", "0002 0000 fffffffe"
        )
        assertNotNull(event)
        assertEquals(2, event!!.type)
        assertEquals(0, event.code)
        assertEquals(-2, event.value)
        assertEquals("/dev/input/event7", event.devicePath)
    }

    @Test fun rejectsUnrelatedLine() {
        assertNull(OtgInputEventReader.parseLine("/dev/input/event1", "waiting for events"))
    }

    @Test fun rejectsUnsafeDevicePathAtApiBoundary() {
        // Path validation is performed by start(); parser itself only parses event lines.
        assertNull(OtgInputEventReader.parseLine("/dev/input/event1", "not an event"))
    }
}
