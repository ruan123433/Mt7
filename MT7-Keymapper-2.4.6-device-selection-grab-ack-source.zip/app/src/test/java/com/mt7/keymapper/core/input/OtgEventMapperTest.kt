package com.mt7.keymapper.core.input

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class OtgEventMapperTest {
    private val mapper = OtgEventMapper()

    private fun event(type: Int, code: Int, value: Int) =
        OtgInputEventReader.InputEvent("/dev/input/event4", type, code, value, null)

    @Test fun mapsWKeyPressAndRelease() {
        val down = mapper.map(event(0x01, 17, 1))!!
        val up = mapper.map(event(0x01, 17, 0))!!
        assertEquals("W", down.label)
        assertEquals(true, down.pressed)
        assertEquals(false, up.pressed)
    }

    @Test fun mapsMouseButtons() {
        val action = mapper.map(event(0x01, 0x110, 1))!!
        assertEquals(OtgEventMapper.Kind.MOUSE_BUTTON, action.kind)
        assertEquals("Mouse esquerdo", action.label)
        assertEquals(true, action.pressed)
    }

    @Test fun mapsRelativeMouseAxesAndScroll() {
        val x = mapper.map(event(0x02, 0x00, -7))!!
        val y = mapper.map(event(0x02, 0x01, 4))!!
        val wheel = mapper.map(event(0x02, 0x08, 1))!!
        assertEquals(-7, x.deltaX)
        assertEquals(4, y.deltaY)
        assertEquals(OtgEventMapper.Kind.SCROLL, wheel.kind)
    }

    @Test fun ignoresSynchronizationUnknownCodesAndInvalidKeyValues() {
        assertNull(mapper.map(event(0x00, 0, 0)))
        assertNull(mapper.map(event(0x01, 999, 1)))
        assertNull(mapper.map(event(0x01, 17, 9)))
    }
}
