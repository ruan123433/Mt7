# MT7 Keymapper 2.3.1 — Android 16 / sem Acessibilidade

## Compatibilidade-alvo
- Android 16 corresponde à API 36.
- O projeto mantém `targetSdk = 36` e `minSdk = 29`.
- `compileSdk = 37` permanece conforme o projeto recebido; instale essa plataforma no Android Studio para compilar.

## Alterações desta revisão
- Removida a exigência de ativar o Serviço de Acessibilidade na tela de permissões.
- Removido o bloqueio por Acessibilidade ao iniciar o serviço flutuante.
- Removidos o serviço de Acessibilidade e seus metadados XML do pacote.
- Atualizada a mensagem de inicialização para não afirmar que WASD/mouse já estão mapeados.
- A verificação Root executa apenas `su -c id`; Shizuku verifica Binder e autorização.

## Estado real do OTG e da injeção
- `TouchInjectionRepository` contém comandos `input tap` e `input swipe` via Root/Shizuku.
- Esses comandos ainda não constituem um dispositivo touchscreen virtual e não fornecem multitouch contínuo.
- A captura global de teclado/mouse OTG por `/dev/input/event*` ou `getevent` ainda NÃO está integrada.
- A ligação entre captura OTG, perfil de mapeamento e injeção também ainda NÃO está pronta.
- `InputDevice` serve apenas para inventário; não captura eventos globalmente.
- Root tem prioridade e Shizuku é fallback no repositório de injeção existente, mas o fluxo completo ainda não está conectado ao serviço.

## Próxima etapa técnica
Implementar um leitor de eventos Linux com backend Root/Shizuku, seleção explícita do dispositivo USB, parser de teclas/botões/deltas e encerramento seguro do processo. Depois integrar eventos ao motor de mapeamento. Em paralelo, avaliar suporte do kernel a `uinput`/dispositivo multitouch no aparelho.

## Validação
Esta revisão é código-fonte. Não foi compilada nem testada em um Redmi Note 14 4G com Android 16. O acesso a `/dev/input`, `getevent` e `uinput` depende do kernel, SELinux, permissões e identidade efetiva do backend.
