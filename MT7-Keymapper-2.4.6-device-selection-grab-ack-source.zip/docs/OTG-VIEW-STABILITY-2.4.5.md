# MT7 2.4.5 — estabilidade da visão e da seta

## Correções nesta revisão

1. **Mouse separado do teclado:** o nó passado em `devicePath` é o mouse e recebe o capturador nativo com `EVIOCGRAB`. `keyboardDevicePath` é opcional e, quando informado como nó separado, é lido por um segundo leitor `getevent` sem grab. Isso evita bloquear WASD ao capturar apenas a interface do mouse.
2. **Falha do grab:** se o helper reportar erro ao ativar o grab, o controlador encerra o modo visão, libera contatos uinput e pausa o runtime. A sessão não continua simulando uma mira exclusiva que o kernel não concedeu.
3. **Modo visão:** o modo só entra em estado ativo se o comando de captura puder ser enviado ao helper. Ao sair, libera o contato virtual e envia o comando de ungrab.
4. **Área segura e reancoragem:** o dedo virtual da câmera fica dentro de 52–97% da largura e 8–92% da altura. Ao atingir a borda, o controlador solta e reancora o contato em torno do ponto de mira configurado, evitando que o contato fique preso na borda e pare de responder.
5. **Sensibilidade baixa:** X/Y de perfil usam passos de 0,1. Frações de movimento do mouse são acumuladas entre eventos; por exemplo, dez deltas de 1 unidade com sensibilidade 0,1 não são descartados como zero.
6. **Scroll:** direção corrigida conforme Linux `REL_WHEEL`: valor positivo corresponde a scroll para cima e negativo a scroll para baixo.
7. **Saída uinput:** todas as escritas de eventos agora são verificadas. Falhas são reportadas e a sessão tenta liberar os contatos antes de destruir o touchscreen virtual.
8. **Empacotamento:** o CMake copia os executáveis PIE do uinput e EVIOCGRAB para uma pasta `jniLibs` gerada por ABI, e o Gradle inclui essa pasta no APK. Isso elimina a dependência de presumir que `add_executable` sozinho será empacotado como biblioteca nativa.
9. **Backend nativo:** a seleção Root primeiro / Shizuku depois verifica diretamente se o event node pode ser lido e se o helper pode ser executado; a captura nativa não depende da presença do binário `getevent`.

## Limitações conhecidas

- `EVIOCGRAB` impede que outros consumidores recebam eventos do nó enquanto o modo visão está ativo. Isso normalmente congela o cursor na posição em que estava, mas **não apaga graficamente a seta**. O Linux evdev não oferece, por si só, um comando universal de ocultação do cursor Android sobre outro aplicativo.
- Para não bloquear WASD, o usuário/integração precisa selecionar o nó correto do mouse e informar o nó do teclado separadamente quando o dongle expõe interfaces diferentes. Se teclado e mouse estiverem combinados no mesmo event node, esse nó combinado será capturado integralmente.
- O callback do modo visão confirma o envio do comando ao helper; a confirmação real do kernel chega assincronamente. Se o `ioctl(EVIOCGRAB)` falhar, a sessão é pausada e os contatos são liberados.
- A área e o ponto de reancoragem são valores iniciais genéricos, não calibrados para cada HUD, resolução, orientação ou versão do Free Fire.
- Não houve teste físico no Redmi Note 14 nem build Gradle/APK nesta validação de host.

## Inicialização

`PrivilegedOtgMappingSession.start(context, devicePath, displayWidth, displayHeight, keyboardDevicePath = ...)`

- `devicePath`: nó Linux do mouse.
- `keyboardDevicePath`: nó Linux do teclado, quando separado.
- Root é tentado primeiro; Shizuku é fallback se tiver acesso efetivo aos nós e ao helper.
