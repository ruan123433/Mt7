# MT7 2.4.6 — seleção OTG e confirmação do modo visão

## Alterações

1. O painel **Dispositivos** agora permite atribuir individualmente cada `/dev/input/eventN` como mouse ou teclado. A escolha é persistida em `mt7_otg_devices` e reaproveitada na próxima abertura; se o nó desaparecer, a tela tenta uma detecção inicial pelo nome e permite atribuição manual.
2. O teste de captura usa `libmt7-input-grab.so` para o nó selecionado como mouse. O teclado, quando separado, continua sendo lido por uma segunda instância `getevent`, sem `EVIOCGRAB`, para não bloquear WASD.
3. O painel mostra controles para iniciar/parar a captura e ativar/liberar o grab durante o diagnóstico.
4. `OtgInputEventReader.setExclusiveGrab()` agora espera uma confirmação do helper (`MT7_GRAB:active` ou `MT7_GRAB:released`) por até 900 ms. Erros do `ioctl(EVIOCGRAB)` e timeouts são retornados como falha, em vez de considerar apenas a escrita do comando como sucesso.
5. Eventos do mouse capturado são entregues em um executor separado do leitor stdout. Isso evita bloquear a thread que precisa receber a confirmação do ioctl enquanto o controlador aguarda o resultado do grab.
6. Ao parar, o leitor acorda qualquer espera pendente, encerra o executor de despacho e envia `Q`; o helper também libera o grab ao fechar o descritor, inclusive em encerramento anormal.

## Limites que permanecem

- `EVIOCGRAB` é captura exclusiva do nó, não um comando gráfico para ocultar o cursor. Em geral, impede novos movimentos para o Android e pode deixar a seta parada na posição anterior; não garante que o desenho da seta desapareça em outro aplicativo.
- A ocultação global do cursor sobre o Free Fire exige integração privilegiada específica do framework/serviço de entrada do Android ou suporte do sistema. Um overlay comum ou `EVIOCGRAB` isoladamente não resolve isso com confiabilidade.
- Se o mouse e teclado compartilham o mesmo event node, selecionar esse nó para `EVIOCGRAB` também captura as teclas nele expostas. Para esse caso, não selecione o mesmo nó como teclado separado. A topologia real depende do dongle/firmware.
- O painel de diagnóstico prova captura e confirmação do grab, não inicia por si só o pipeline de toque no Free Fire. A sessão `PrivilegedOtgMappingSession` ainda precisa ser conectada ao fluxo de serviço/UI de jogo.
- O teste de host não substitui build Gradle nem teste no aparelho Android 16.

## Como usar o painel

1. Conceda Root ou Shizuku e toque em **Buscar nós**.
2. Em cada nó listado, atribua **Usar como mouse** e, se houver interface separada, **Usar como teclado**.
3. Toque em **Testar captura nativa**.
4. Use **Ativar captura exclusiva** para confirmar o grab e **Liberar captura exclusiva** para devolver os eventos ao sistema.
5. Toque em **Parar** antes de trocar o dispositivo ou desconectar o dongle.
