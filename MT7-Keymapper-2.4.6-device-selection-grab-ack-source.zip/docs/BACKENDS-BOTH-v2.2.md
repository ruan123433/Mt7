# Backends Root + Shizuku — etapa inicial 2.2

Esta etapa melhora a confirmação de autorização dos dois backends, sem afirmar que já existe injeção de entrada privilegiada.

- Root: executa somente `su -c id`, aguarda no máximo 3 segundos e considera Root confirmado apenas quando o processo termina com sucesso e informa `uid=0`. O gerenciador de superusuário pode exibir uma solicitação de autorização.
- Shizuku: confirma Binder ativo e permissão explícita do MT7; a identidade/UID continua sendo informativa.
- `ActivationRepository.inspectBothNow()` retorna os dois estados para a interface poder exibi-los lado a lado.
- Nenhum dos probes altera arquivos, modifica Free Fire ou injeta eventos.

## Limites

A captura de entrada da versão 2.1 continua baseada no Serviço de Acessibilidade. Esta etapa não converte Root/Shizuku em backend de injeção e não promete compatibilidade/funcionamento no Free Fire. A próxima etapa deve definir e testar uma ponte de entrada autorizada no aparelho, com fallback claro e sem tentar contornar anti-cheat ou proteções do jogo.
