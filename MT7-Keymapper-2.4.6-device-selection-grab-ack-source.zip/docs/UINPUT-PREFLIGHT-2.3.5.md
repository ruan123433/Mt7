# MT7 2.3.5 — pré-diagnóstico de uinput

## O que entrou

- `UinputCapabilityInspector` executa uma verificação somente de leitura, com Root primeiro e Shizuku como alternativa.
- Verifica a presença de um nó de caractere em `/dev/uinput` ou `/dev/input/uinput`.
- Registra se o backend informa permissões de leitura/escrita, se `/sys/module/uinput` está presente e o modo SELinux, quando `getenforce` existe.
- O painel **Dispositivos de entrada** ganhou o botão **Verificar uinput** e apresenta o resultado.
- Testes unitários cobrem nó gravável, nó presente sem acesso e nó ausente.

## Segurança e limites

Este diagnóstico não abre o nó para escrita, não altera permissões, não carrega módulos, não executa `setenforce`, não cria dispositivo virtual e não injeta eventos. `test -r`/`test -w` é uma indicação de permissões do processo, não uma prova de que `UI_DEV_CREATE` funcionará. A criação de touchscreen virtual ainda exige implementação nativa do protocolo uinput (ioctl e estruturas `input_event`), permissões efetivas e compatibilidade do kernel/SELinux.

Shizuku pode executar como UID shell (2000), que normalmente não tem acesso de escrita ao nó uinput. A tentativa Root é priorizada, mas depende de um gerenciador su funcional e de aprovação do usuário.

## Validação pendente

- Não há Android SDK, Gradle instalado nem `gradlew` no pacote neste ambiente; build e testes Gradle não foram executados.
- O resultado no Redmi Note 14 4G / Android 16 precisa ser coletado no aparelho pelo botão **Verificar uinput**.
- Mesmo com `WRITABLE`, a próxima etapa será um teste controlado de criação/remoção de dispositivo virtual, sem enviar toques ao jogo.
