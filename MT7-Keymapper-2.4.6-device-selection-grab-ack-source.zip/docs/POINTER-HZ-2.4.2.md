# MT7 2.4.2 — polling e seta do mouse

## Polling Hz
Os perfis agora guardam a preferência de 125, 250, 500 ou 1000 Hz. O valor não altera o firmware nem o polling USB real do mouse: essa taxa é negociada pelo dispositivo/host Android e depende do hardware e do kernel. A interface deve apresentar o valor como preferência selecionada, não como taxa física medida.

## Suspensão da seta durante a mira
O `OtgTouchMappingController` aceita `onPointerSuspensionChanged(Boolean)`. Com `suspendPointerWhileAiming=true`, envia `true` ao iniciar o arrasto de visão com o botão direito, e `false` ao terminar, pausar ou cancelar os contatos. `PrivilegedOtgMappingSession.start` expõe esse callback para a camada de plataforma.

Esse callback define corretamente o ciclo de vida da suspensão, mas não esconde sozinho o cursor Android global. Para ocultar a seta sobre um jogo externo é necessário um mecanismo compatível com o sistema/janela do jogo; `View.requestPointerCapture()` só captura ponteiro na janela que possui foco e não pode ser aplicado arbitrariamente ao Free Fire por um serviço overlay. Não declarar a seta globalmente oculta até essa integração ser implementada e validada no dispositivo.

## Testes
Os testes unitários verificam a transição true/false da suspensão e a propagação das preferências Hz e de suspensão ao `TouchLayout`.
