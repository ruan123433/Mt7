# MT7 2.3.9 — transporte persistente uinput

## O que foi adicionado

- O helper nativo ganhou o modo `--serve`, que abre `/dev/uinput`, configura um touchscreen virtual multitouch e mantém o descritor aberto.
- O helper aceita comandos pela entrada padrão: `D pointerId x y` (down), `M pointerId x y` (move), `U pointerId x y` (up), `C` (cancelar todos) e `Q` (encerrar).
- Os eventos são escritos como `struct input_event`, com `ABS_MT_SLOT`, `ABS_MT_TRACKING_ID`, coordenadas MT e `SYN_REPORT`.
- O helper libera todos os contatos e executa `UI_DEV_DESTROY` ao receber `Q` ou EOF.
- `UinputTouchSession` mantém o processo vivo, envia comandos e tenta Root primeiro; Shizuku só é aceito se o helper sinalizar `MT7_UINPUT_SESSION:ready` após criar o dispositivo.

## Limites desta versão

- A sessão está implementada como transporte independente, mas ainda não foi ligada ao `MappingRuntime` nem ao leitor OTG. Portanto, ainda não é um keymapper jogável.
- A escala de coordenadas usa os limites informados na inicialização. A calibração com resolução/densidade/orientação do display ainda precisa ser ligada ao perfil.
- Não foi possível testar a criação real em Android neste ambiente. O sucesso do compilador host não comprova acesso a `/dev/uinput` no Redmi.
- Shizuku pode não ter permissão para abrir `/dev/uinput`; a sessão só o considera válido se o helper criar o dispositivo de fato.
- O fechamento normal libera os contatos e destrói o dispositivo. Em encerramento abrupto, fechar o descritor também remove o dispositivo no kernel; ainda será necessário integrar watchdog e ciclo de vida do serviço.

## Formato do protocolo interno

Uma linha por comando, escrita em stdin do helper privilegiado. O processo não expõe uma porta de rede nem usa Acessibilidade. `Q` é o comando de encerramento; EOF também encerra a sessão.
