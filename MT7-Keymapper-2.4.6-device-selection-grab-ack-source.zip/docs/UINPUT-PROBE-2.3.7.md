# MT7 2.3.7 — helper nativo de preflight uinput

## O que foi acrescentado

- `app/src/main/cpp/uinput_probe.cpp`: executável nativo independente para Android/Linux.
- O helper abre o nó uinput, configura capacidades multitouch (slots, tracking ID, X/Y), declara a propriedade `INPUT_PROP_DIRECT`, executa `UI_DEV_SETUP` e `UI_DEV_CREATE`, aguarda 100 ms e executa `UI_DEV_DESTROY`.
- O helper não escreve nenhum `struct input_event`: não toca na tela, não move o cursor e não interage com o Free Fire.
- `UinputProbeResult` interpreta apenas os marcadores de sucesso/falha emitidos pelo helper, sem considerar saída vazia ou código zero isolado como prova de sucesso.
- Testes unitários cobrem criação/remocão confirmada, falha de permissão e saída sem marcador.

## Limites deliberados desta versão

Este é um helper de verificação real de `UI_DEV_CREATE`, mas ainda não está empacotado como binário executável dentro do APK nem conectado ao fluxo de autorização Root/Shizuku. O CMake declara o alvo `mt7-uinput-probe` para compilação; a próxima integração precisa copiar o artefato correto por ABI para armazenamento privado, validar caminho/ABI, e iniciá-lo via Root primeiro e Shizuku apenas se o UID do serviço tiver acesso efetivo.

Não presumir que Shizuku com UID 2000 consegue abrir `/dev/uinput`. A autorização do Shizuku e a leitura/escrita reportada pelo diagnóstico não comprovam que `UI_DEV_CREATE` seja permitido. SELinux também pode negar a operação mesmo com permissões Unix aparentes.

A chamada futura deverá usar caminho fixo gerado pelo próprio app, argumentos numéricos validados e timeout. Não interpolar texto fornecido pelo usuário em comandos `su -c` ou `sh -c`.

## Segurança e estado

- Nenhuma permissão de Acessibilidade foi adicionada.
- Nenhuma alteração de permissões em `/dev/uinput`, `chmod`, `chown`, `setenforce` ou carregamento de módulo foi implementada.
- A criação do dispositivo é transitória e seguida imediatamente de remoção.
- O helper ainda não é um transporte de eventos; a injeção multitouch real continua pendente.

## Validação realizada nesta etapa

- Compilação host do helper com `g++ -std=c++17 -Wall -Wextra -Werror`.
- Execução de `--help` confirmada.
- Não foi executado em Android, não houve tentativa de abrir `/dev/uinput` no aparelho, não houve build Gradle/APK e os testes JUnit ainda dependem de execução no pipeline Android.
