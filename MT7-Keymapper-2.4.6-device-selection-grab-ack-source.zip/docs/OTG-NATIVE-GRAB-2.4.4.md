# MT7 2.4.4 — captura nativa com EVIOCGRAB sob demanda

## O que mudou

- Novo executável nativo `libmt7-input-grab.so`, compilado para as ABIs configuradas no projeto.
- O helper abre um nó `/dev/input/eventN` de mouse em modo somente leitura e observa `input_event`.
- O helper inicia sem capturar exclusivamente o dispositivo. Recebe `G` pelo stdin para executar `ioctl(EVIOCGRAB, 1)` e `R` para executar `ioctl(EVIOCGRAB, 0)`.
- O modo de visão do mapper envia `G` ao ativar e `R` ao desativar. O leitor continua recebendo eventos durante os dois estados.
- Ao encerrar, o helper libera explicitamente o grab e fecha o descritor; o kernel também libera o grab quando o descritor é fechado.
- Root continua sendo tentado primeiro; Shizuku é fallback conforme as verificações existentes.

## Limitações e cuidados

- EVIOCGRAB é aplicado ao nó selecionado. O usuário deve escolher o event node do mouse, não o teclado nem a touchscreen física.
- Enquanto o grab estiver ativo, outros consumidores Linux/Android deixam de receber os eventos desse nó. Um dispositivo combinado mouse+teclado pode, portanto, bloquear também suas teclas; selecionar a interface correta é essencial.
- EVIOCGRAB interrompe a entrega de movimento/cliques ao sistema enquanto ativo, mas não é uma API para ocultar graficamente o ícone do cursor. A seta pode permanecer visível e parada; ocultação global precisa de validação/integração específica do Android.
- A taxa USB física não é alterada por este helper.
- O helper precisa estar empacotado no APK como executável ELF e ser executável pelo backend escolhido. O empacotamento final pelo Android Gradle Plugin ainda precisa ser confirmado em um APK real.
- Shizuku (UID shell) pode não ter permissão para abrir/grab o nó de entrada; Root é o caminho prioritário.
- Não foi possível testar EVIOCGRAB em hardware Android nesta validação de host.

## Protocolo

- stdin `G`: tentar ativar grab exclusivo.
- stdin `R`: liberar grab exclusivo.
- stdin `Q`: encerrar e liberar.
- stdout `MT7_GRAB:ready`, `MT7_GRAB:active`, `MT7_GRAB:released`, `MT7_GRAB:closed` e mensagens `MT7_GRAB:failed:...`.
- Eventos são emitidos como `type code value` hexadecimal e consumidos pelo parser OTG existente.


## Revisão de estabilidade 2.4.5

- O capturador nativo agora seleciona Root/Shizuku verificando diretamente acesso ao event node e execução do helper; não exige `getevent` para a captura nativa do mouse.
- O teclado pode ser informado como um segundo event node e continua usando captura normal sem `EVIOCGRAB`. Isso evita bloquear WASD quando mouse e teclado são interfaces separadas ou quando o mesmo dongle expõe nós separados.
- A falha assíncrona do `EVIOCGRAB` encerra o modo de visão e libera contatos virtuais; a sessão pausa para evitar toques presos.
- O controlador só entra no modo de visão se o envio do pedido de grab for aceito.
- A área do contato de visão fica limitada à região direita da tela (52–97% da largura, 8–92% da altura), evitando que o dedo virtual atravesse o HUD ou fique preso nas bordas físicas.
- Corrigida a direção do scroll vertical conforme `REL_WHEEL` do Linux: positivo = para cima; negativo = para baixo.
- A captura exclusiva congela a entrega de movimento ao cursor do Android enquanto ativa; não é uma API de ocultação gráfica global. O cursor pode permanecer visível e parado.

## Parâmetros de inicialização

`PrivilegedOtgMappingSession.start` mantém `devicePath` como nó do mouse e aceita `keyboardDevicePath` opcional para o teclado. Se o teclado for um nó separado, informe-o para preservar WASD durante o grab do mouse. O usuário deve selecionar o event node identificado como mouse; não selecionar touchscreen física.
