# Validação manual necessária — MT7 2.3.3

1. Instalar o APK gerado pelo Android Studio/GitHub Actions.
2. Conceder Root ou iniciar Shizuku e autorizar o MT7.
3. Conectar teclado e mouse via OTG.
4. Abrir **Dispositivos** e tocar em **Buscar nós**.
5. Selecionar um nó, tocar em **Capturar eventos** e testar teclas, movimento e botões.
6. Confirmar que os eventos aparecem, que **Parar** encerra a leitura e que sair da tela também encerra o processo.
7. Repetir com Root e Shizuku separadamente; registrar mensagens de erro e nós inacessíveis.

Não testar em partida competitiva nem assumir que a captura já controla o jogo. Esta etapa apenas observa os eventos.
