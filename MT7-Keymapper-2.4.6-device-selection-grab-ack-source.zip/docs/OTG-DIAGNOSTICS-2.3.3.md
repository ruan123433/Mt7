# MT7 2.3.3 — integração inicial da captura OTG

## O que mudou
- O painel **Dispositivos** agora consulta `getevent -pl` por backend privilegiado e lista os nós `/dev/input/eventN` acessíveis.
- Permite selecionar um nó e iniciar/parar uma leitura contínua com `getevent -t`.
- Mostra até 80 eventos recentes (timestamp, type, code e value) para diagnóstico.
- A leitura roda fora da thread de UI e é encerrada quando o painel sai de composição.
- O executor de comandos privilegiados passa a drenar stdout/stderr enquanto o processo executa, evitando o deadlock causado por esperar o processo antes de ler o pipe. A saída capturada é limitada a 64 KiB.
- O parser aceita timestamp `getevent` com espaços de preenchimento dentro dos colchetes.

## Limites importantes
- Esta é uma ferramenta de diagnóstico somente de leitura. Nenhum evento é convertido em toque, movimento do ponteiro ou gesto.
- Não há ainda hotplug automático dos nós privilegiados; use **Buscar nós** após conectar/desconectar periféricos.
- Root é tentado primeiro; Shizuku é fallback. A disponibilidade depende de `getevent`, permissões reais sobre `/dev/input` e políticas SELinux do aparelho.
- O formato de saída e o acesso precisam ser confirmados no Redmi Note 14 4G com Android 16. Um backend que aparece como autorizado não garante que consiga ler cada nó.
- Não foi possível compilar ou executar testes nesta sessão: o ZIP não inclui `gradlew` e não há instalação local do Gradle disponível no ambiente.

## Próxima etapa
Após validar a captura real, implementar a camada de interpretação (teclas, movimento e botões do mouse), seguida por uma solução de injeção multitouch compatível com o kernel. A injeção não deve ser considerada implementada nesta versão.
