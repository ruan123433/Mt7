# MT7 2.3.8 — execução privilegiada do probe uinput

Esta versão conecta o helper C++ `libmt7-uinput-probe.so` ao app Android por um executor Kotlin.

- O app procura o helper no `nativeLibraryDir`.
- Tenta executar o helper por `su -c` primeiro.
- Se Root não concluir a operação, tenta Shizuku.
- O helper abre `/dev/uinput`, configura capacidades multitouch, chama `UI_DEV_CREATE`, aguarda brevemente e chama `UI_DEV_DESTROY`.
- Não escreve registros `input_event`; portanto, não injeta toques nem controla o Free Fire.
- O resultado informa qual backend conseguiu criar e remover o dispositivo.

## Limitações e validação

O empacotamento do executável standalone no diretório de bibliotecas nativas depende do comportamento do AGP/NDK na build Android e deve ser confirmado em APK instalado. Shizuku normalmente executa como UID shell e pode não ter permissão/SELinux para abrir `/dev/uinput`. O fallback só é considerado bem-sucedido se o helper confirmar criação e remoção.

Esta alteração não constitui ainda um transporte persistente de eventos, nem integração com o protocolo multitouch ou com o motor de mapeamento. Não foi realizado teste físico no aparelho.
